package net.knightsmp.admintools.gui;

import net.knightsmp.admintools.AdminToolsPlugin;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.List;

/** 45 entries per page (rows 1-5), footer in row 6: 45 prev, 48 page info, 49 back, 53 next; 46/47/50-52 free. */
public abstract class PagedMenu<T> extends Menu {
    protected static final int PAGE_SIZE = 45;
    protected int page = 0;
    protected List<T> entries = List.of();

    protected PagedMenu(AdminToolsPlugin plugin, Player viewer, Menu parent) {
        super(plugin, viewer, parent);
    }

    protected abstract List<T> load();

    protected abstract ItemStack render(T entry);

    protected void onSelect(T entry) {}

    protected void footer() {}

    @Override
    protected void beforeOpen() {
        entries = load();
    }

    protected void reload() {
        entries = load();
        refresh();
    }

    @Override
    protected void build() {
        int pages = Math.max(1, (entries.size() + PAGE_SIZE - 1) / PAGE_SIZE);
        page = Math.max(0, Math.min(page, pages - 1));
        for (int i = 0; i < PAGE_SIZE; i++) {
            int idx = page * PAGE_SIZE + i;
            if (idx >= entries.size()) break;
            T entry = entries.get(idx);
            set(i, render(entry), () -> onSelect(entry));
        }
        for (int i = 45; i < 54; i++) set(i, Items.border());
        if (page > 0) set(45, Items.make(Material.ARROW, "<gray>« Previous page"), () -> { page--; refresh(); });
        if (page < pages - 1) set(53, Items.make(Material.ARROW, "<gray>Next page »"), () -> { page++; refresh(); });
        set(48, Items.make(Material.PAPER, "<gray>Page <white>" + (page + 1) + "<gray>/<white>" + pages,
                "<dark_gray>" + entries.size() + " entries"));
        set(49, Items.make(Material.ARROW, parent != null ? "<yellow>« Back" : "<red>Close"), this::back);
        footer();
    }
}
