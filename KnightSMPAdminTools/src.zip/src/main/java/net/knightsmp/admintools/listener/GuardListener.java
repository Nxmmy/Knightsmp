package net.knightsmp.admintools.listener;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.knightsmp.admintools.AdminToolsPlugin;
import net.knightsmp.admintools.TimeUtil;
import net.knightsmp.admintools.db.Punishment;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;

import java.sql.SQLException;
import java.util.Locale;
import java.util.Optional;

/** Enforces bans, mutes and freezes. */
public final class GuardListener implements Listener {
    private final AdminToolsPlugin plugin;

    public GuardListener(AdminToolsPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onPreLogin(AsyncPlayerPreLoginEvent e) {
        try {
            Optional<Punishment> ban = plugin.moderation().activeBan(e.getUniqueId(), e.getName());
            if (ban.isPresent()) {
                Punishment p = ban.get();
                e.disallow(AsyncPlayerPreLoginEvent.Result.KICK_BANNED, plugin.messages().get("ban-screen",
                        "reason", String.valueOf(p.reason()), "admin", p.adminName(), "expires", TimeUtil.expiry(p.expires())));
            }
        } catch (SQLException ex) {
            // Fail open so a DB fault cannot lock the whole server out; it is logged loudly.
            plugin.getLogger().severe("Ban check failed for " + e.getName() + ": " + ex.getMessage());
        }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onChat(AsyncChatEvent e) {
        if (checkMuted(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        String msg = e.getMessage();
        if (msg.length() < 2) return;
        String label = msg.substring(1).split(" ", 2)[0].toLowerCase(Locale.ROOT);
        int colon = label.indexOf(':');
        if (colon >= 0) label = label.substring(colon + 1);
        if (!plugin.getConfig().getStringList("settings.muted-blocked-commands").contains(label)) return;
        if (checkMuted(e.getPlayer())) e.setCancelled(true);
    }

    private boolean checkMuted(Player p) {
        try {
            Optional<Punishment> mute = plugin.moderation().activeMute(p.getUniqueId(), p.getName());
            if (mute.isPresent()) {
                plugin.messages().send(p, "muted-notice", "remaining", TimeUtil.remaining(mute.get().expires()),
                        "reason", String.valueOf(mute.get().reason()));
                return true;
            }
        } catch (SQLException ex) {
            plugin.getLogger().severe("Mute check failed for " + p.getName() + ": " + ex.getMessage());
        }
        return false;
    }

    // ---------------- freeze ----------------

    private boolean frozen(Player p) {
        return plugin.moderation().isFrozen(p.getUniqueId());
    }

    @EventHandler(ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        if (!frozen(e.getPlayer())) return;
        Location from = e.getFrom();
        Location to = e.getTo();
        if (to == null) return;
        if (from.getX() != to.getX() || from.getY() != to.getY() || from.getZ() != to.getZ()) {
            e.setTo(new Location(from.getWorld(), from.getX(), from.getY(), from.getZ(), to.getYaw(), to.getPitch()));
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        if (frozen(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        if (frozen(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent e) {
        if (frozen(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent e) {
        if (frozen(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onAttack(EntityDamageByEntityEvent e) {
        if (e.getDamager() instanceof Player p && frozen(p)) e.setCancelled(true);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        if (frozen(e.getPlayer())) plugin.messages().send(e.getPlayer(), "frozen-notice");
    }
}
