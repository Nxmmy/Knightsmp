package net.knightsmp.admintools.gui;

import net.knightsmp.admintools.AdminToolsPlugin;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;

public final class MainMenu extends Menu {

    public MainMenu(AdminToolsPlugin plugin, Player viewer) {
        super(plugin, viewer, null);
    }

    @Override
    protected String title() {
        return "<dark_gray>▌ <gold>KnightSMP <dark_gray>» <gray>Admin Panel";
    }

    @Override
    protected int rows() {
        return 5;
    }

    @Override
    protected void build() {
        set(4, Items.make(Material.NETHER_STAR, "<gold><bold>KnightSMP Admin Tools",
                "<gray>Online: <white>" + Bukkit.getOnlinePlayers().size() + "<gray>/<white>" + Bukkit.getMaxPlayers(),
                "<dark_gray>OP-only. All actions are logged."));
        set(10, Items.make(Material.PLAYER_HEAD, "<aqua>Player Management",
                "<gray>Online players, info, game mode,", "<gray>teleport, freeze, history"),
                () -> goTo(new PlayerListMenu(plugin, viewer, this, "Player Management",
                        (list, p) -> new PlayerActionMenu(plugin, viewer, list, p.getUniqueId(), p.getName()))));
        set(11, Items.make(Material.NETHERITE_AXE, "<red>Moderation",
                "<gray>Recent punishments, revoke bans/mutes,", "<gray>punish an online player"),
                () -> goTo(new ModerationMenu(plugin, viewer, this)));
        set(12, Items.make(Material.CHEST, "<yellow>Inventory Inspection",
                "<gray>View and confiscate items from", "<gray>an online player"),
                () -> goTo(new PlayerListMenu(plugin, viewer, this, "Inventory Inspection", (list, p) -> {
                    if (p.getUniqueId().equals(viewer.getUniqueId())) {
                        plugin.messages().send(viewer, "inv-self");
                        return list;
                    }
                    return new InventoryMenu(plugin, viewer, list, p.getUniqueId(), p.getName());
                })));
        set(13, Items.make(Material.ENDER_EYE, "<light_purple>X-Ray Inspection",
                "<gray>Hidden ores and containers", "<gray>(admin-only, server-side)"),
                () -> goTo(new XrayMenu(plugin, viewer, this)));
        set(14, Items.make(Material.CLOCK, "<green>Server Monitoring",
                "<gray>TPS, memory, uptime, plugins"),
                () -> goTo(new MonitorMenu(plugin, viewer, this)));
        set(15, Items.make(Material.WRITABLE_BOOK, "<gold>Staff Logs",
                "<gray>Every admin action and denied attempt"),
                () -> goTo(new LogsMenu(plugin, viewer, this)));
        set(16, Items.make(Material.COMPARATOR, "<white>Settings",
                "<gray>Scan radii and toggles"),
                () -> goTo(new SettingsMenu(plugin, viewer, this)));
        set(40, Items.make(Material.BARRIER, "<red>Close"), this::close);
    }
}
