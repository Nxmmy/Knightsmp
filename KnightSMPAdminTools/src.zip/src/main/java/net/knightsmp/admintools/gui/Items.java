package net.knightsmp.admintools.gui;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.Arrays;
import java.util.List;

/** Item/Component helpers for the dark theme. Dynamic text MUST go through esc() before being put in a MiniMessage string. */
public final class Items {
    private static final MiniMessage MM = MiniMessage.miniMessage();

    private Items() {}

    public static Component c(String mini) {
        return MM.deserialize(mini).decorationIfAbsent(TextDecoration.ITALIC, TextDecoration.State.FALSE);
    }

    public static String esc(String s) {
        return MM.escapeTags(s == null ? "" : s);
    }

    public static ItemStack make(Material m, String name, String... lore) {
        return make(m, 1, name, Arrays.asList(lore));
    }

    public static ItemStack make(Material m, int amount, String name, List<String> lore) {
        ItemStack it = new ItemStack(m, Math.max(1, Math.min(amount, 64)));
        ItemMeta meta = it.getItemMeta();
        meta.displayName(c(name));
        if (!lore.isEmpty()) {
            meta.lore(lore.stream().map(Items::c).toList());
        }
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ADDITIONAL_TOOLTIP, ItemFlag.HIDE_ENCHANTS);
        it.setItemMeta(meta);
        return it;
    }

    public static ItemStack head(OfflinePlayer p, String name, String... lore) {
        ItemStack it = make(Material.PLAYER_HEAD, name, lore);
        if (it.getItemMeta() instanceof SkullMeta sm) {
            sm.setOwningPlayer(p);
            it.setItemMeta(sm);
        }
        return it;
    }

    public static ItemStack filler() {
        return make(Material.BLACK_STAINED_GLASS_PANE, " ");
    }

    public static ItemStack border() {
        return make(Material.GRAY_STAINED_GLASS_PANE, " ");
    }

    public static ItemStack empty(String label) {
        return make(Material.GRAY_STAINED_GLASS_PANE, "<dark_gray>" + label);
    }
}
