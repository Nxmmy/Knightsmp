package net.knightsmp.admintools.gui;

import net.knightsmp.admintools.AdminToolsPlugin;
import net.knightsmp.admintools.db.Punishment;
import net.knightsmp.admintools.service.ModerationService;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.sql.SQLException;
import java.util.List;
import java.util.UUID;

public final class ModerationMenu extends PagedMenu<Punishment> {

    public ModerationMenu(AdminToolsPlugin plugin, Player viewer, Menu parent) {
        super(plugin, viewer, parent);
    }

    @Override
    protected String title() {
        return "<dark_gray>Moderation <gray>» <white>Recent punishments";
    }

    @Override
    protected List<Punishment> load() {
        try {
            return plugin.database().recentPunishments(450);
        } catch (SQLException e) {
            plugin.getLogger().severe("Punishment load failed: " + e.getMessage());
            plugin.messages().send(viewer, "db-error");
            return List.of();
        }
    }

    @Override
    protected ItemStack render(Punishment p) {
        List<String> extra = p.isLive() && (p.type().equals("BAN") || p.type().equals("MUTE"))
                ? List.of("", "<yellow>Click to revoke") : List.of("", "<yellow>Click for this player's history");
        ItemStack it = HistoryMenu.renderPunishment(p, false);
        var meta = it.getItemMeta();
        var lore = new java.util.ArrayList<>(meta.lore());
        extra.forEach(l -> lore.add(Items.c(l)));
        meta.lore(lore);
        it.setItemMeta(meta);
        return it;
    }

    @Override
    protected void onSelect(Punishment p) {
        UUID uuid = p.targetUuid() == null ? null : UUID.fromString(p.targetUuid());
        if (p.isLive() && (p.type().equals("BAN") || p.type().equals("MUTE"))) {
            boolean ban = p.type().equals("BAN");
            goTo(new ConfirmMenu(plugin, viewer, this, (ban ? "Unban " : "Unmute ") + p.targetName(),
                    List.of("<gray>Revokes the active " + p.type().toLowerCase() + "."), () -> {
                ModerationService mod = plugin.moderation();
                ModerationService.Target t = mod.resolve(p.targetName());
                if (t == null) return;
                if (ban) mod.unban(viewer, t);
                else mod.unmute(viewer, t);
            }));
        } else {
            goTo(new HistoryMenu(plugin, viewer, this, uuid, p.targetName()));
        }
    }

    @Override
    protected void footer() {
        set(46, Items.make(Material.PLAYER_HEAD, "<aqua>Punish an online player", "<gray>Warn / kick / mute / ban"),
                () -> goTo(new PlayerListMenu(plugin, viewer, this, "Moderation",
                        (list, p) -> new PlayerActionMenu(plugin, viewer, list, p.getUniqueId(), p.getName()))));
        set(47, Items.make(Material.SUNFLOWER, "<green>Refresh"), this::reload);
    }
}
