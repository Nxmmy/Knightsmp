package net.knightsmp.admintools;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class TimeUtil {
    private static final DateTimeFormatter FMT =
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss").withZone(ZoneId.systemDefault());
    private static final Pattern PART = Pattern.compile("(\\d{1,7})([smhdw])");
    private static final long MAX_MS = 3650L * 24 * 3600 * 1000;

    private TimeUtil() {}

    /** @return millis; 0 = permanent; -1 = invalid. */
    public static long parseDuration(String input) {
        if (input == null) return -1;
        String s = input.toLowerCase(Locale.ROOT).trim();
        if (s.equals("perm") || s.equals("permanent") || s.equals("forever")) return 0;
        Matcher m = PART.matcher(s);
        int pos = 0;
        long total = 0;
        while (m.find()) {
            if (m.start() != pos) return -1;
            pos = m.end();
            long n = Long.parseLong(m.group(1));
            long unit = switch (m.group(2)) {
                case "s" -> 1000L;
                case "m" -> 60_000L;
                case "h" -> 3_600_000L;
                case "d" -> 86_400_000L;
                default -> 604_800_000L;
            };
            total += n * unit;
            if (total > MAX_MS) return -1;
        }
        if (pos != s.length() || total <= 0) return -1;
        return total;
    }

    public static String formatDuration(long ms) {
        if (ms <= 0) return "permanent";
        long s = ms / 1000;
        long d = s / 86400; s %= 86400;
        long h = s / 3600; s %= 3600;
        long m = s / 60; s %= 60;
        StringBuilder sb = new StringBuilder();
        if (d > 0) sb.append(d).append("d ");
        if (h > 0) sb.append(h).append("h ");
        if (m > 0) sb.append(m).append("m ");
        if (s > 0 || sb.isEmpty()) sb.append(s).append("s");
        return sb.toString().trim();
    }

    public static String date(long epochMs) {
        return FMT.format(Instant.ofEpochMilli(epochMs));
    }

    public static String expiry(long expiresMs) {
        return expiresMs == 0 ? "never" : date(expiresMs);
    }

    public static String remaining(long expiresMs) {
        return expiresMs == 0 ? "permanent" : formatDuration(Math.max(0, expiresMs - System.currentTimeMillis()));
    }
}
