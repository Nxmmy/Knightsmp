package net.knightsmp.admintools.gui;

import net.knightsmp.admintools.AdminToolsPlugin;
import org.bukkit.Material;
import org.bukkit.entity.Player;

import java.util.List;

/** Generic confirmation screen. The action runs only on the green button, after a fresh OP check. */
public final class ConfirmMenu extends Menu {
    private final String heading;
    private final List<String> lines;
    private final Runnable action;

    public ConfirmMenu(AdminToolsPlugin plugin, Player viewer, Menu back, String heading, List<String> lines, Runnable action) {
        super(plugin, viewer, back);
        this.heading = heading;
        this.lines = lines;
        this.action = action;
    }

    @Override
    protected String title() {
        return "<dark_gray>Confirm <gray>» <red>" + Items.esc(heading);
    }

    @Override
    protected int rows() {
        return 3;
    }

    @Override
    protected void build() {
        set(11, Items.make(Material.LIME_CONCRETE, "<green><bold>CONFIRM", "<gray>" + Items.esc(heading)), () -> {
            if (!plugin.security().requireOp(viewer, "confirm:" + heading)) return;
            action.run();
            if (parent != null) goTo(parent);
            else close();
        });
        set(13, Items.make(Material.PAPER, 1, "<yellow>" + Items.esc(heading), lines));
        set(15, Items.make(Material.RED_CONCRETE, "<red><bold>CANCEL", "<gray>Nothing will happen"), this::back);
    }
}
