package net.knightsmp.admintools.gui;

import net.knightsmp.admintools.AdminToolsPlugin;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

public final class SettingsMenu extends Menu {

    public SettingsMenu(AdminToolsPlugin plugin, Player viewer, Menu parent) {
        super(plugin, viewer, parent);
    }

    @Override
    protected String title() {
        return "<dark_gray>Settings";
    }

    @Override
    protected int rows() {
        return 4;
    }

    private void change(String path, Object value) {
        if (!plugin.security().requireOp(viewer, "change-setting:" + path)) return;
        plugin.getConfig().set(path, value);
        plugin.saveConfig();
        plugin.database().logAction(viewer.getUniqueId(), viewer.getName(), "SETTING_CHANGE", path, String.valueOf(value));
        refresh();
    }

    private void radiusRow(int baseSlot, String path, String maxPath, int def, int step, int min, String name, Material icon) {
        FileConfiguration c = plugin.getConfig();
        int max = c.getInt(maxPath, def);
        int cur = Math.min(c.getInt(path, def), max);
        set(baseSlot, Items.make(Material.RED_CONCRETE, "<red>- " + step), () -> change(path, Math.max(min, cur - step)));
        set(baseSlot + 1, Items.make(icon, "<aqua>" + name + ": <white>" + cur, "<gray>Min " + min + ", max " + max,
                "<dark_gray>Max is set in config.yml"));
        set(baseSlot + 2, Items.make(Material.LIME_CONCRETE, "<green>+ " + step), () -> change(path, Math.min(max, cur + step)));
    }

    private void toggle(int slot, String path, boolean def, String name, String hint) {
        boolean on = plugin.getConfig().getBoolean(path, def);
        set(slot, Items.make(on ? Material.LIME_DYE : Material.GRAY_DYE, "<white>" + name + ": " + (on ? "<green>ON" : "<red>OFF"),
                "<gray>" + hint, "<yellow>Click to toggle"), () -> change(path, !on));
    }

    @Override
    protected void build() {
        radiusRow(10, "settings.ore-scan.radius", "settings.ore-scan.max-radius", 16, 4, 4, "Ore scan radius", Material.DIAMOND_ORE);
        radiusRow(14, "settings.chest-scan.radius", "settings.chest-scan.max-radius", 48, 16, 16, "Chest scan radius", Material.CHEST);
        toggle(19, "settings.ore-scan.hidden-only", true, "Ore: hidden only", "Skip ores touching air/water");
        toggle(20, "settings.broadcast-punishments", true, "Public punishments", "Announce to all players");
        toggle(21, "settings.protect-operators", true, "Protect operators", "OPs cannot be punished here");
        set(23, Items.make(Material.COMPARATOR, "<yellow>Reload config.yml", "<gray>Re-read file from disk"), () -> {
            if (!plugin.security().requireOp(viewer, "reload-config")) return;
            plugin.reloadAll();
            plugin.database().logAction(viewer.getUniqueId(), viewer.getName(), "RELOAD_CONFIG", "-", "");
            plugin.messages().send(viewer, "reloaded");
            refresh();
        });
        set(31, Items.make(Material.ARROW, "<yellow>« Back"), this::back);
    }
}
