package net.knightsmp.admintools.gui;

import net.knightsmp.admintools.AdminToolsPlugin;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Read-only chest-style view of an ONLINE player's inventory. The menu never contains real items - only clones.
 * Items move ONLY through confiscate(), which (on the main thread, atomically):
 *   1. re-reads the live slot and requires it to equal what the admin saw (type, amount, meta),
 *   2. proves on a simulated copy that the admin's inventory can hold the full stack,
 *   3. removes it from the target and adds it to the admin,
 *   4. restores any unexpected leftover to the target slot,
 *   5. records admin + exact item (serialized bytes) in the staff log and confiscations table.
 *
 * Layout: GUI rows 1-4 = inventory slots 0-35 (row 1 = hotbar). Row 6: 45-48 helmet/chest/legs/boots, 50 offhand.
 */
public final class InventoryMenu extends Menu {
    private static final int[] ARMOR_GUI = {45, 46, 47, 48};
    private static final int[] ARMOR_INV = {39, 38, 37, 36};
    private static final String[] ARMOR_NAME = {"Helmet", "Chestplate", "Leggings", "Boots"};
    private static final int OFFHAND_GUI = 50;
    private static final int OFFHAND_INV = 40;

    private final UUID targetId;
    private final String targetName;
    /** gui slot -> exact clone of the live item at render time (used for the "did it change?" check). */
    private final Map<Integer, ItemStack> snapshot = new HashMap<>();

    public InventoryMenu(AdminToolsPlugin plugin, Player viewer, Menu parent, UUID targetId, String targetName) {
        super(plugin, viewer, parent);
        this.targetId = targetId;
        this.targetName = targetName;
    }

    @Override
    protected String title() {
        return "<dark_gray>Inventory <gray>» <white>" + Items.esc(targetName);
    }

    @Override
    protected void afterOpen() {
        plugin.database().logAction(viewer.getUniqueId(), viewer.getName(), "INVENTORY_INSPECT", targetName, "");
    }

    private static int invSlotFor(int guiSlot) {
        if (guiSlot >= 0 && guiSlot < 36) return guiSlot;
        for (int i = 0; i < 4; i++) if (ARMOR_GUI[i] == guiSlot) return ARMOR_INV[i];
        return guiSlot == OFFHAND_GUI ? OFFHAND_INV : -1;
    }

    private static String labelFor(int invSlot) {
        if (invSlot < 9) return "Hotbar " + (invSlot + 1);
        if (invSlot < 36) return "Storage " + invSlot;
        for (int i = 0; i < 4; i++) if (ARMOR_INV[i] == invSlot) return ARMOR_NAME[i];
        return "Offhand";
    }

    private void show(Player t, int guiSlot, String emptyLabel) {
        int invSlot = invSlotFor(guiSlot);
        ItemStack live = t.getInventory().getItem(invSlot);
        if (live == null || live.getType().isAir()) {
            set(guiSlot, Items.empty(emptyLabel));
            return;
        }
        snapshot.put(guiSlot, live.clone());
        ItemStack display = live.clone();
        ItemMeta meta = display.getItemMeta();
        List<Component> lore = meta.lore() != null ? new ArrayList<>(meta.lore()) : new ArrayList<>();
        lore.add(Component.empty());
        lore.add(Items.c("<dark_gray>" + labelFor(invSlot)));
        lore.add(Items.c("<red>Click to confiscate"));
        meta.lore(lore);
        display.setItemMeta(meta);
        set(guiSlot, display, () -> requestConfiscate(guiSlot));
    }

    @Override
    protected void build() {
        snapshot.clear();
        Player t = Bukkit.getPlayer(targetId);
        set(49, Items.make(Material.ARROW, parent != null ? "<yellow>« Back" : "<red>Close"), this::back);
        if (t == null) {
            set(22, Items.make(Material.BARRIER, "<red>" + Items.esc(targetName) + " is offline",
                    "<gray>Only online players can be inspected."));
            return;
        }
        for (int i = 36; i < 45; i++) set(i, Items.border());
        for (int g = 0; g < 36; g++) show(t, g, "Empty");
        for (int i = 0; i < 4; i++) show(t, ARMOR_GUI[i], ARMOR_NAME[i] + " (empty)");
        show(t, OFFHAND_GUI, "Offhand (empty)");
        set(40, Items.head(t, "<aqua>" + Items.esc(t.getName()),
                "<gray>Row 1: hotbar, rows 2-4: storage", "<gray>Bottom: armor + offhand",
                "<dark_gray>Read-only until you confirm a confiscation"));
        set(51, Items.make(Material.SUNFLOWER, "<green>Refresh"), this::refresh);
        set(53, Items.make(Material.HOPPER, "<red>Confiscate ALL", "<gray>" + snapshot.size() + " stack(s)",
                "<gray>Everything that fits in your inventory"), this::requestConfiscateAll);
    }

    private void requestConfiscate(int guiSlot) {
        ItemStack expected = snapshot.get(guiSlot);
        if (expected == null) return;
        String desc = describe(expected);
        goTo(new ConfirmMenu(plugin, viewer, this, "Confiscate " + expected.getType().name(),
                List.of("<gray>Item: <white>" + Items.esc(desc), "<gray>From: <white>" + Items.esc(targetName),
                        "<red>Moves to YOUR inventory."),
                () -> confiscate(guiSlot, expected)));
    }

    private void requestConfiscateAll() {
        if (snapshot.isEmpty()) return;
        Map<Integer, ItemStack> copy = new HashMap<>(snapshot);
        goTo(new ConfirmMenu(plugin, viewer, this, "Confiscate ALL from " + targetName,
                List.of("<gray>Stacks: <white>" + copy.size(), "<red>Moves to YOUR inventory,",
                        "<red>stopping what does not fit."),
                () -> {
                    int ok = 0, skipped = 0;
                    for (Map.Entry<Integer, ItemStack> e : copy.entrySet()) {
                        if (confiscate(e.getKey(), e.getValue(), false)) ok++;
                        else skipped++;
                    }
                    plugin.messages().send(viewer, "inv-confiscated-all", "count", ok, "player", targetName, "skipped", skipped);
                }));
    }

    private boolean confiscate(int guiSlot, ItemStack expected) {
        return confiscate(guiSlot, expected, true);
    }

    private static String describe(ItemStack it) {
        String name = it.getType().name() + " x" + it.getAmount();
        if (it.hasItemMeta() && it.getItemMeta().hasDisplayName()) {
            name += " (named)";
        }
        return name;
    }

    private boolean confiscate(int guiSlot, ItemStack expected, boolean report) {
        // Re-validate authorization at the moment of the actual transfer.
        if (!plugin.security().requireOp(viewer, "confiscate-item")) return false;
        Player target = Bukkit.getPlayer(targetId);
        if (target == null) {
            plugin.messages().send(viewer, "inv-target-offline");
            return false;
        }
        if (target.getUniqueId().equals(viewer.getUniqueId())) {
            plugin.messages().send(viewer, "inv-self");
            return false;
        }
        int invSlot = invSlotFor(guiSlot);
        PlayerInventory targetInv = target.getInventory();
        ItemStack live = targetInv.getItem(invSlot);
        if (live == null || live.getType().isAir() || !live.equals(expected)) {
            if (report) plugin.messages().send(viewer, "inv-item-changed");
            return false;
        }
        // Prove it fits using a throw-away copy of the admin's storage (addItem only uses slots 0-35).
        Inventory sim = Bukkit.createInventory(null, 36);
        ItemStack[] storage = viewer.getInventory().getStorageContents();
        ItemStack[] copy = new ItemStack[storage.length];
        for (int i = 0; i < storage.length; i++) copy[i] = storage[i] == null ? null : storage[i].clone();
        sim.setContents(copy);
        if (!sim.addItem(live.clone()).isEmpty()) {
            if (report) plugin.messages().send(viewer, "inv-full");
            return false;
        }
        // Commit: all on the main thread, no yields between remove and add.
        ItemStack moving = live.clone();
        targetInv.setItem(invSlot, null);
        Map<Integer, ItemStack> leftover = viewer.getInventory().addItem(moving);
        if (!leftover.isEmpty()) {
            // Should be unreachable after the simulation; if it happens, give the unplaced part back. Nothing is lost.
            targetInv.setItem(invSlot, leftover.values().iterator().next());
            plugin.getLogger().warning("Confiscation partially placed; remainder returned to " + targetName);
        }
        target.updateInventory();
        viewer.updateInventory();

        int placedAmount = moving.getAmount() - leftover.values().stream().mapToInt(ItemStack::getAmount).sum();
        String desc = moving.getType().name() + " x" + placedAmount + " from " + labelFor(invSlot);
        plugin.database().logAction(viewer.getUniqueId(), viewer.getName(), "ITEM_CONFISCATED", targetName, desc);
        try {
            plugin.database().addConfiscation(viewer.getUniqueId(), viewer.getName(), targetId, targetName,
                    labelFor(invSlot), moving.getType().name(), placedAmount, moving.serializeAsBytes());
        } catch (SQLException e) {
            // The items already moved safely; make sure the evidence is not silently lost.
            plugin.getLogger().severe("Confiscation DB write failed (items are with " + viewer.getName() + "): "
                    + desc + " | " + e.getMessage());
        }
        if (report) plugin.messages().send(viewer, "inv-confiscated", "item", desc, "player", targetName);
        return true;
    }
}
