package net.knightsmp.admintools.gui;

import net.knightsmp.admintools.AdminToolsPlugin;
import net.knightsmp.admintools.TimeUtil;
import net.knightsmp.admintools.db.LogEntry;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.sql.SQLException;
import java.util.List;
import java.util.Set;

public final class LogsMenu extends PagedMenu<LogEntry> {
    private enum Filter {
        ALL("All", Set.of()),
        MODERATION("Moderation", Set.of("KICK", "BAN", "UNBAN", "MUTE", "UNMUTE", "WARN", "FREEZE", "UNFREEZE")),
        INSPECTION("Inspections", Set.of("INVENTORY_INSPECT", "ITEM_CONFISCATED", "ORE_INSPECT", "ORE_TELEPORT",
                "CHEST_SCAN", "CHEST_INSPECT", "CHEST_TELEPORT")),
        SECURITY("Denied access", Set.of("ACCESS_DENIED"));

        final String display;
        final Set<String> actions;

        Filter(String display, Set<String> actions) {
            this.display = display;
            this.actions = actions;
        }
    }

    private Filter filter = Filter.ALL;

    public LogsMenu(AdminToolsPlugin plugin, Player viewer, Menu parent) {
        super(plugin, viewer, parent);
    }

    @Override
    protected String title() {
        return "<dark_gray>Staff Logs";
    }

    @Override
    protected List<LogEntry> load() {
        try {
            List<LogEntry> all = plugin.database().recentLogs(plugin.getConfig().getInt("settings.log-gui-limit", 450));
            if (filter == Filter.ALL) return all;
            return all.stream().filter(e -> filter.actions.contains(e.action())).toList();
        } catch (SQLException e) {
            plugin.getLogger().severe("Log load failed: " + e.getMessage());
            plugin.messages().send(viewer, "db-error");
            return List.of();
        }
    }

    @Override
    protected ItemStack render(LogEntry e) {
        boolean denied = e.action().equals("ACCESS_DENIED");
        Material icon = denied ? Material.RED_STAINED_GLASS_PANE
                : e.action().startsWith("ITEM") ? Material.HOPPER
                : e.action().contains("INSPECT") || e.action().contains("SCAN") ? Material.ENDER_EYE
                : Material.PAPER;
        return Items.make(icon, 1, (denied ? "<red>" : "<gold>") + e.action(),
                List.of("<gray>Time: <white>" + TimeUtil.date(e.ts()),
                        "<gray>Admin: <white>" + Items.esc(e.adminName()),
                        "<gray>Target: <white>" + Items.esc(e.target()),
                        "<gray>Details: <white>" + Items.esc(e.details())));
    }

    @Override
    protected void footer() {
        set(46, Items.make(Material.HOPPER, "<aqua>Filter: <white>" + filter.display, "<yellow>Click to cycle"), () -> {
            Filter[] all = Filter.values();
            filter = all[(filter.ordinal() + 1) % all.length];
            page = 0;
            reload();
        });
        set(47, Items.make(Material.SUNFLOWER, "<green>Refresh"), this::reload);
    }
}
