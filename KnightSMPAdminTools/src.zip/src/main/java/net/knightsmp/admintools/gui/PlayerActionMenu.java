package net.knightsmp.admintools.gui;

import net.knightsmp.admintools.AdminToolsPlugin;
import net.knightsmp.admintools.TimeUtil;
import net.knightsmp.admintools.service.ModerationService;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Player;

import java.util.List;
import java.util.UUID;

public final class PlayerActionMenu extends Menu {
    private final UUID targetId;
    private final String targetName;

    public PlayerActionMenu(AdminToolsPlugin plugin, Player viewer, Menu parent, UUID targetId, String targetName) {
        super(plugin, viewer, parent);
        this.targetId = targetId;
        this.targetName = targetName;
    }

    @Override
    protected String title() {
        return "<dark_gray>Player <gray>» <white>" + Items.esc(targetName);
    }

    @Override
    protected void build() {
        ModerationService mod = plugin.moderation();
        Player t = Bukkit.getPlayer(targetId);
        set(49, Items.make(Material.ARROW, "<yellow>« Back"), this::back);
        set(23, Items.make(Material.BOOK, "<gold>Punishment history", "<gray>View all warns, kicks, bans, mutes"),
                () -> goTo(new HistoryMenu(plugin, viewer, this, targetId, targetName)));
        if (t == null) {
            set(4, Items.make(Material.BARRIER, "<red>" + Items.esc(targetName) + " is offline",
                    "<gray>Only history is available."));
            return;
        }
        boolean self = viewer.getUniqueId().equals(targetId);
        AttributeInstance maxAttr = t.getAttribute(Attribute.MAX_HEALTH);
        double maxHp = maxAttr != null ? maxAttr.getValue() : 20.0;
        int warns = mod.warnCount(mod.targetOf(t));
        set(4, Items.head(t, "<aqua><bold>" + Items.esc(t.getName()),
                "<gray>UUID: <dark_gray>" + t.getUniqueId(),
                "<gray>Health: <white>" + String.format("%.1f / %.1f", t.getHealth(), maxHp),
                "<gray>Food: <white>" + t.getFoodLevel() + "/20 <dark_gray>(sat " + String.format("%.1f", t.getSaturation()) + ")",
                "<gray>XP level: <white>" + t.getLevel(),
                "<gray>Game mode: <white>" + t.getGameMode().name(),
                "<gray>World: <white>" + Items.esc(t.getWorld().getName()),
                "<gray>Position: <white>" + t.getLocation().getBlockX() + " " + t.getLocation().getBlockY() + " " + t.getLocation().getBlockZ(),
                "<gray>Ping: <white>" + t.getPing() + "ms",
                "<gray>Frozen: <white>" + mod.isFrozen(targetId),
                "<gray>Warnings on record: <white>" + (warns < 0 ? "?" : String.valueOf(warns))));

        set(19, Items.make(Material.COMMAND_BLOCK, "<aqua>Game mode: <white>" + t.getGameMode().name(),
                "<yellow>Click to cycle"), () -> {
            GameMode next = switch (t.getGameMode()) {
                case SURVIVAL -> GameMode.CREATIVE;
                case CREATIVE -> GameMode.ADVENTURE;
                case ADVENTURE -> GameMode.SPECTATOR;
                case SPECTATOR -> GameMode.SURVIVAL;
            };
            mod.setGameMode(viewer, t, next);
            refresh();
        });
        set(20, Items.make(Material.ENDER_PEARL, "<light_purple>Teleport to player",
                self ? "<red>That is you." : "<yellow>Click to teleport"), () -> {
            if (!self) mod.teleportToPlayer(viewer, t);
        });
        boolean frozen = mod.isFrozen(targetId);
        set(21, Items.make(frozen ? Material.PACKED_ICE : Material.ICE, frozen ? "<aqua>Unfreeze player" : "<aqua>Freeze player",
                "<gray>Blocks movement, building,", "<gray>interaction and attacking"), () -> {
            if (frozen) mod.unfreeze(viewer, mod.targetOf(t));
            else mod.freeze(viewer, mod.targetOf(t));
            refresh();
        });
        set(22, Items.make(Material.CHEST, "<yellow>Inspect inventory",
                self ? "<red>You cannot inspect yourself." : "<gray>View / confiscate items"), () -> {
            if (self) plugin.messages().send(viewer, "inv-self");
            else goTo(new InventoryMenu(plugin, viewer, this, targetId, targetName));
        });

        String reason = plugin.getConfig().getString("settings.default-reason", "Violation of server rules");
        String muteDur = plugin.getConfig().getString("settings.quick-mute-duration", "30m");
        long muteMs = Math.max(0, TimeUtil.parseDuration(muteDur));
        List<String> hint = List.of("<gray>Reason: <white>" + Items.esc(reason),
                "<dark_gray>Custom reason: use the slash command");
        set(28, Items.make(Material.YELLOW_DYE, "<yellow>Warn", "<gray>Reason: <white>" + Items.esc(reason)),
                () -> goTo(new ConfirmMenu(plugin, viewer, this, "Warn " + targetName, hint,
                        () -> mod.warn(viewer, mod.targetOf(t), reason))));
        set(29, Items.make(Material.IRON_DOOR, "<gold>Kick", "<gray>Reason: <white>" + Items.esc(reason)),
                () -> goTo(new ConfirmMenu(plugin, viewer, this, "Kick " + targetName, hint,
                        () -> mod.kick(viewer, mod.targetOf(t), reason))));
        set(30, Items.make(Material.BELL, "<red>Mute (" + Items.esc(muteDur) + ")", "<gray>Reason: <white>" + Items.esc(reason)),
                () -> goTo(new ConfirmMenu(plugin, viewer, this, "Mute " + targetName + " (" + muteDur + ")", hint,
                        () -> mod.mute(viewer, mod.targetOf(t), muteMs, reason))));
        set(31, Items.make(Material.BARRIER, "<dark_red>Ban (permanent)", "<gray>Reason: <white>" + Items.esc(reason)),
                () -> goTo(new ConfirmMenu(plugin, viewer, this, "BAN " + targetName, hint,
                        () -> mod.ban(viewer, mod.targetOf(t), reason))));
    }
}
