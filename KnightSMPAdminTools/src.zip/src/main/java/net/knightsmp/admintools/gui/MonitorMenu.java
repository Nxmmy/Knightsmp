package net.knightsmp.admintools.gui;

import net.knightsmp.admintools.AdminToolsPlugin;
import net.knightsmp.admintools.TimeUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

import java.lang.management.ManagementFactory;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public final class MonitorMenu extends Menu {

    public MonitorMenu(AdminToolsPlugin plugin, Player viewer, Menu parent) {
        super(plugin, viewer, parent);
    }

    @Override
    protected String title() {
        return "<dark_gray>Server Monitoring";
    }

    @Override
    protected int rows() {
        return 4;
    }

    private static String tpsColor(double tps) {
        return tps >= 19 ? "<green>" : tps >= 15 ? "<yellow>" : "<red>";
    }

    @Override
    protected void build() {
        set(10, Items.make(Material.PLAYER_HEAD, "<aqua>Players",
                "<gray>Online: <white>" + Bukkit.getOnlinePlayers().size() + "<gray>/<white>" + Bukkit.getMaxPlayers()));

        double[] tps = Bukkit.getTPS();
        double mspt = Bukkit.getAverageTickTime();
        set(11, Items.make(Material.CLOCK, "<green>Performance",
                "<gray>TPS 1m: " + tpsColor(tps[0]) + String.format("%.2f", Math.min(20.0, tps[0])),
                "<gray>TPS 5m: " + tpsColor(tps[1]) + String.format("%.2f", Math.min(20.0, tps[1])),
                "<gray>TPS 15m: " + tpsColor(tps[2]) + String.format("%.2f", Math.min(20.0, tps[2])),
                "<gray>Avg tick: <white>" + String.format("%.2f", mspt) + " ms"));

        long up = ManagementFactory.getRuntimeMXBean().getUptime();
        set(12, Items.make(Material.COMPARATOR, "<yellow>Uptime", "<gray>" + TimeUtil.formatDuration(up),
                "<dark_gray>(JVM uptime)"));

        Runtime rt = Runtime.getRuntime();
        long max = rt.maxMemory() / 1048576, total = rt.totalMemory() / 1048576, used = total - rt.freeMemory() / 1048576;
        set(13, Items.make(Material.REDSTONE, "<red>Memory",
                "<gray>Used: <white>" + used + " MB",
                "<gray>Allocated: <white>" + total + " MB",
                "<gray>Max: <white>" + max + " MB",
                "<gray>Usage: <white>" + (max == 0 ? 0 : used * 100 / max) + "%"));

        List<String> info = new ArrayList<>();
        info.add("<gray>Server: <white>" + Items.esc(Bukkit.getName() + " " + Bukkit.getMinecraftVersion()));
        info.add("<gray>Java: <white>" + Items.esc(System.getProperty("java.version")));
        info.add("<gray>OS: <white>" + Items.esc(System.getProperty("os.name")));
        for (World w : Bukkit.getWorlds()) {
            info.add("<dark_gray>" + Items.esc(w.getName()) + ": <gray>" + w.getChunkCount() + " chunks, "
                    + w.getEntityCount() + " entities");
        }
        set(14, Items.make(Material.GRASS_BLOCK, 1, "<green>Server & worlds", info));

        Plugin[] plugins = Bukkit.getPluginManager().getPlugins();
        Arrays.sort(plugins, Comparator.comparing(p -> p.getName().toLowerCase()));
        List<String> pl = new ArrayList<>();
        int shown = 0;
        for (Plugin p : plugins) {
            if (shown++ >= 22) {
                pl.add("<dark_gray>... +" + (plugins.length - 22) + " more");
                break;
            }
            pl.add((p.isEnabled() ? "<green>" : "<red>") + Items.esc(p.getName()) + " <dark_gray>"
                    + Items.esc(p.getPluginMeta().getVersion()));
        }
        set(15, Items.make(Material.BOOKSHELF, 1, "<light_purple>Plugins <gray>(" + plugins.length + ")", pl));

        set(30, Items.make(Material.SUNFLOWER, "<green>Refresh"), this::refresh);
        set(31, Items.make(Material.ARROW, "<yellow>« Back"), this::back);
    }
}
