package net.knightsmp.admintools.gui;

import net.knightsmp.admintools.AdminToolsPlugin;
import net.knightsmp.admintools.scan.ChestScanner.ContainerHit;
import net.knightsmp.admintools.service.TeleportHelper;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Container;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

/** Read-only copy of a live container's contents (items are clones; the real container is never opened). */
public final class ChestViewMenu extends Menu {
    private static final int PAGE = 45;
    private final ContainerHit hit;
    private int page;

    public ChestViewMenu(AdminToolsPlugin plugin, Player viewer, Menu parent, ContainerHit hit) {
        super(plugin, viewer, parent);
        this.hit = hit;
    }

    @Override
    protected String title() {
        return "<dark_gray>Container <gray>» <white>" + hit.x() + " " + hit.y() + " " + hit.z();
    }

    @Override
    protected void afterOpen() {
        Container c = resolve();
        int used = 0;
        if (c != null) {
            for (ItemStack it : c.getInventory().getContents()) if (it != null && !it.getType().isAir()) used++;
        }
        plugin.database().logAction(viewer.getUniqueId(), viewer.getName(), "CHEST_INSPECT", hit.worldName(),
                hit.material().name() + " at " + hit.x() + "," + hit.y() + "," + hit.z() + " stacks=" + used);
    }

    private Container resolve() {
        World w = Bukkit.getWorld(hit.worldId());
        if (w == null || !w.isChunkLoaded(hit.x() >> 4, hit.z() >> 4)) return null;
        return w.getBlockAt(hit.x(), hit.y(), hit.z()).getState(false) instanceof Container c ? c : null;
    }

    @Override
    protected void build() {
        for (int i = 45; i < 54; i++) set(i, Items.border());
        set(49, Items.make(Material.ARROW, "<yellow>« Back"), this::back);
        Container c = resolve();
        if (c == null) {
            set(22, Items.make(Material.BARRIER, "<red>Container unavailable",
                    "<gray>Removed or chunk unloaded."));
            return;
        }
        ItemStack[] contents = c.getInventory().getContents();
        int pages = Math.max(1, (contents.length + PAGE - 1) / PAGE);
        page = Math.max(0, Math.min(page, pages - 1));
        for (int i = 0; i < PAGE; i++) {
            int idx = page * PAGE + i;
            if (idx >= contents.length) break;
            ItemStack it = contents[idx];
            set(i, it == null || it.getType().isAir() ? Items.empty("Empty") : it.clone());
        }
        if (page > 0) set(45, Items.make(Material.ARROW, "<gray>« Previous page"), () -> { page--; refresh(); });
        if (page < pages - 1) set(53, Items.make(Material.ARROW, "<gray>Next page »"), () -> { page++; refresh(); });
        set(48, Items.make(Material.PAPER, "<gold>" + hit.material().name(),
                "<gray>Position: <white>" + hit.x() + " " + hit.y() + " " + hit.z(),
                "<gray>World: <white>" + Items.esc(hit.worldName()),
                "<gray>Page <white>" + (page + 1) + "<gray>/<white>" + pages,
                "<dark_gray>Read-only copy"));
        set(46, Items.make(Material.SUNFLOWER, "<green>Refresh"), this::refresh);
        set(47, Items.make(Material.ENDER_PEARL, "<light_purple>Teleport here"), () -> {
            if (TeleportHelper.toBlock(plugin, viewer, Bukkit.getWorld(hit.worldId()), hit.x(), hit.y(), hit.z())) {
                plugin.database().logAction(viewer.getUniqueId(), viewer.getName(), "CHEST_TELEPORT", hit.worldName(),
                        hit.x() + "," + hit.y() + "," + hit.z());
            }
        });
    }
}
