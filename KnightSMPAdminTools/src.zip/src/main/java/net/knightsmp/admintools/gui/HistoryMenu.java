package net.knightsmp.admintools.gui;

import net.knightsmp.admintools.AdminToolsPlugin;
import net.knightsmp.admintools.TimeUtil;
import net.knightsmp.admintools.db.Punishment;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.sql.SQLException;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public final class HistoryMenu extends PagedMenu<Punishment> {
    private final UUID targetId;
    private final String targetName;

    public HistoryMenu(AdminToolsPlugin plugin, Player viewer, Menu parent, UUID targetId, String targetName) {
        super(plugin, viewer, parent);
        this.targetId = targetId;
        this.targetName = targetName;
    }

    @Override
    protected String title() {
        return "<dark_gray>History <gray>» <white>" + Items.esc(targetName);
    }

    @Override
    protected List<Punishment> load() {
        try {
            return plugin.database().history(targetId, targetName.toLowerCase(Locale.ROOT), 450);
        } catch (SQLException e) {
            plugin.getLogger().severe("History load failed: " + e.getMessage());
            plugin.messages().send(viewer, "db-error");
            return List.of();
        }
    }

    @Override
    protected ItemStack render(Punishment p) {
        return renderPunishment(p, true);
    }

    static ItemStack renderPunishment(Punishment p, boolean hideTarget) {
        Material icon = switch (p.type()) {
            case "BAN" -> Material.BARRIER;
            case "MUTE" -> Material.BELL;
            case "KICK" -> Material.IRON_DOOR;
            default -> Material.YELLOW_DYE;
        };
        String state = switch (p.type()) {
            case "BAN", "MUTE" -> p.isLive() ? "<red>ACTIVE" : "<green>inactive/expired";
            default -> "<gray>-";
        };
        return Items.make(icon, 1, "<gold>#" + p.id() + " <white>" + p.type()
                        + (hideTarget ? "" : " <gray>» <aqua>" + Items.esc(p.targetName())),
                List.of("<gray>Date: <white>" + TimeUtil.date(p.ts()),
                        "<gray>By: <white>" + Items.esc(p.adminName()),
                        "<gray>Reason: <white>" + Items.esc(p.reason()),
                        "<gray>Expires: <white>" + TimeUtil.expiry(p.expires()),
                        "<gray>State: " + state));
    }
}
