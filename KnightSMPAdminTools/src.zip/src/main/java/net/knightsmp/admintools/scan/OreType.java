package net.knightsmp.admintools.scan;

import org.bukkit.Material;

import java.util.EnumMap;
import java.util.Map;

public enum OreType {
    COAL("Coal", Material.COAL_ORE, Material.DEEPSLATE_COAL_ORE),
    IRON("Iron", Material.IRON_ORE, Material.DEEPSLATE_IRON_ORE),
    COPPER("Copper", Material.COPPER_ORE, Material.DEEPSLATE_COPPER_ORE),
    GOLD("Gold", Material.GOLD_ORE, Material.DEEPSLATE_GOLD_ORE),
    REDSTONE("Redstone", Material.REDSTONE_ORE, Material.DEEPSLATE_REDSTONE_ORE),
    LAPIS("Lapis", Material.LAPIS_ORE, Material.DEEPSLATE_LAPIS_ORE),
    DIAMOND("Diamond", Material.DIAMOND_ORE, Material.DEEPSLATE_DIAMOND_ORE),
    EMERALD("Emerald", Material.EMERALD_ORE, Material.DEEPSLATE_EMERALD_ORE),
    NETHER_QUARTZ("Nether Quartz", Material.NETHER_QUARTZ_ORE),
    NETHER_GOLD("Nether Gold", Material.NETHER_GOLD_ORE),
    ANCIENT_DEBRIS("Ancient Debris", Material.ANCIENT_DEBRIS);

    private static final Map<Material, OreType> BY_MATERIAL = new EnumMap<>(Material.class);

    static {
        for (OreType t : values()) {
            for (Material m : t.materials) BY_MATERIAL.put(m, t);
        }
    }

    private final String display;
    private final Material[] materials;

    OreType(String display, Material... materials) {
        this.display = display;
        this.materials = materials;
    }

    public String display() {
        return display;
    }

    public Material icon() {
        return materials[0];
    }

    public static OreType of(Material m) {
        return BY_MATERIAL.get(m);
    }
}
