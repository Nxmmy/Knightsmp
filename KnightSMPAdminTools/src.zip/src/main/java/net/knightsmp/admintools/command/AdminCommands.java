package net.knightsmp.admintools.command;

import net.knightsmp.admintools.AdminToolsPlugin;
import net.knightsmp.admintools.TimeUtil;
import net.knightsmp.admintools.db.Punishment;
import net.knightsmp.admintools.gui.InventoryMenu;
import net.knightsmp.admintools.gui.MainMenu;
import net.knightsmp.admintools.service.ModerationService;
import net.knightsmp.admintools.service.ModerationService.Target;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

public final class AdminCommands implements CommandExecutor, TabCompleter {
    private final AdminToolsPlugin plugin;

    public AdminCommands(AdminToolsPlugin plugin) {
        this.plugin = plugin;
    }

    private ModerationService mod() {
        return plugin.moderation();
    }

    private boolean usage(CommandSender s, String usage) {
        plugin.messages().send(s, "usage", "usage", usage);
        return true;
    }

    private String joinFrom(String[] args, int from) {
        return String.join(" ", Arrays.copyOfRange(args, from, args.length));
    }

    private Target target(CommandSender s, String name) {
        Target t = mod().resolve(name);
        if (t == null) plugin.messages().send(s, "invalid-name");
        return t;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        String name = cmd.getName().toLowerCase(Locale.ROOT);
        // Server-side OP check FIRST, for every command, before looking at any argument.
        if (!plugin.security().require(sender, "/" + name + (args.length > 0 ? " " + String.join(" ", args) : ""))) {
            return true;
        }
        try {
            return switch (name) {
                case "admin" -> admin(sender, args);
                case "inventorycheck" -> inventoryCheck(sender, args);
                case "kick" -> {
                    if (args.length < 2) yield usage(sender, "/kick <player> <reason>");
                    Target t = target(sender, args[0]);
                    if (t != null) mod().kick(sender, t, joinFrom(args, 1));
                    yield true;
                }
                case "ban" -> {
                    if (args.length < 2) yield usage(sender, "/ban <player> <reason>");
                    Target t = target(sender, args[0]);
                    if (t != null) mod().ban(sender, t, joinFrom(args, 1));
                    yield true;
                }
                case "unban" -> {
                    if (args.length != 1) yield usage(sender, "/unban <player>");
                    Target t = target(sender, args[0]);
                    if (t != null) mod().unban(sender, t);
                    yield true;
                }
                case "mute" -> {
                    if (args.length < 3) yield usage(sender, "/mute <player> <duration> <reason>");
                    long ms = TimeUtil.parseDuration(args[1]);
                    if (ms < 0) {
                        plugin.messages().send(sender, "invalid-duration");
                        yield true;
                    }
                    Target t = target(sender, args[0]);
                    if (t != null) mod().mute(sender, t, ms, joinFrom(args, 2));
                    yield true;
                }
                case "unmute" -> {
                    if (args.length != 1) yield usage(sender, "/unmute <player>");
                    Target t = target(sender, args[0]);
                    if (t != null) mod().unmute(sender, t);
                    yield true;
                }
                case "warn" -> {
                    if (args.length < 2) yield usage(sender, "/warn <player> <reason>");
                    Target t = target(sender, args[0]);
                    if (t != null) mod().warn(sender, t, joinFrom(args, 1));
                    yield true;
                }
                case "history" -> history(sender, args);
                case "freeze" -> {
                    if (args.length != 1) yield usage(sender, "/freeze <player>");
                    Target t = target(sender, args[0]);
                    if (t != null) mod().freeze(sender, t);
                    yield true;
                }
                case "unfreeze" -> {
                    if (args.length != 1) yield usage(sender, "/unfreeze <player>");
                    Target t = target(sender, args[0]);
                    if (t != null) mod().unfreeze(sender, t);
                    yield true;
                }
                default -> false;
            };
        } catch (RuntimeException ex) {
            plugin.getLogger().severe("Error running /" + name + ": " + ex);
            plugin.messages().send(sender, "internal-error");
            return true;
        }
    }

    private boolean admin(CommandSender sender, String[] args) {
        if (args.length >= 1 && args[0].equalsIgnoreCase("reload")) {
            plugin.reloadAll();
            plugin.database().logAction(sender instanceof Player p ? p.getUniqueId() : null, sender.getName(),
                    "RELOAD_CONFIG", "-", "");
            plugin.messages().send(sender, "reloaded");
            return true;
        }
        if (!(sender instanceof Player player)) {
            plugin.messages().send(sender, "player-only");
            return true;
        }
        new MainMenu(plugin, player).open();
        return true;
    }

    private boolean inventoryCheck(CommandSender sender, String[] args) {
        if (!(sender instanceof Player admin)) {
            plugin.messages().send(sender, "player-only");
            return true;
        }
        if (args.length != 1) return usage(sender, "/inventorycheck <username>");
        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) {
            plugin.messages().send(sender, "player-not-found", "player", args[0]);
            return true;
        }
        if (target.equals(admin)) {
            plugin.messages().send(sender, "inv-self");
            return true;
        }
        new InventoryMenu(plugin, admin, null, target.getUniqueId(), target.getName()).open();
        return true;
    }

    private boolean history(CommandSender sender, String[] args) {
        if (args.length != 1) return usage(sender, "/history <player>");
        Target t = target(sender, args[0]);
        if (t == null) return true;
        try {
            List<Punishment> list = plugin.database().history(t.uuid(), t.name().toLowerCase(Locale.ROOT), 10);
            if (list.isEmpty()) {
                plugin.messages().send(sender, "history-empty", "player", t.name());
                return true;
            }
            plugin.messages().send(sender, "history-header", "player", t.name(), "count", list.size());
            for (Punishment p : list) {
                String state = p.isLive() ? "(ACTIVE)" : "";
                sender.sendMessage(plugin.messages().get("history-line", "id", p.id(), "type", p.type(),
                        "date", TimeUtil.date(p.ts()), "admin", p.adminName(), "reason", String.valueOf(p.reason()), "state", state));
            }
        } catch (SQLException e) {
            plugin.getLogger().severe("History query failed: " + e.getMessage());
            plugin.messages().send(sender, "db-error");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] args) {
        if (!plugin.security().isAdmin(sender)) return List.of();   // never leak anything to non-OPs
        String name = cmd.getName().toLowerCase(Locale.ROOT);
        if (name.equals("admin")) return args.length == 1 ? filter(List.of("reload"), args[0]) : List.of();
        if (args.length == 1) {
            return filter(Bukkit.getOnlinePlayers().stream().map(Player::getName).collect(Collectors.toList()), args[0]);
        }
        if (name.equals("mute") && args.length == 2) return filter(List.of("10m", "30m", "1h", "1d", "7d", "perm"), args[1]);
        return List.of();
    }

    private List<String> filter(List<String> options, String prefix) {
        String p = prefix.toLowerCase(Locale.ROOT);
        return options.stream().filter(o -> o.toLowerCase(Locale.ROOT).startsWith(p)).sorted().collect(Collectors.toList());
    }
}
