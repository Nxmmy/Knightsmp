package net.knightsmp.admintools.service;

import net.knightsmp.admintools.AdminToolsPlugin;
import net.knightsmp.admintools.TimeUtil;
import net.knightsmp.admintools.db.Punishment;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.sql.SQLException;
import java.util.Locale;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;

/**
 * All moderation / player-management actions. Used by BOTH commands and GUI. Every public action re-checks
 * OP status itself (defence in depth: it does not trust that the caller already did).
 */
public final class ModerationService {

    public record Target(UUID uuid, String name, Player online) {}

    private static final Pattern NAME = Pattern.compile("[A-Za-z0-9_.]{1,32}");
    private final AdminToolsPlugin plugin;
    private final Set<UUID> frozen = ConcurrentHashMap.newKeySet();

    public ModerationService(AdminToolsPlugin plugin) {
        this.plugin = plugin;
    }

    // ---------- target resolution ----------

    /** @return null if the input is not a plausible player name. Offline/never-joined names are allowed (name-based). */
    public Target resolve(String input) {
        if (input == null || !NAME.matcher(input).matches()) return null;
        Player p = Bukkit.getPlayerExact(input);
        if (p != null) return targetOf(p);
        OfflinePlayer op = Bukkit.getOfflinePlayerIfCached(input);
        if (op != null) {
            return new Target(op.getUniqueId(), op.getName() != null ? op.getName() : input, null);
        }
        return new Target(null, input, null);
    }

    public Target targetOf(Player p) {
        return new Target(p.getUniqueId(), p.getName(), p);
    }

    public boolean isFrozen(UUID id) {
        return frozen.contains(id);
    }

    // ---------- helpers ----------

    private UUID uuidOf(CommandSender s) {
        return s instanceof Player p ? p.getUniqueId() : null;
    }

    private String lower(Target t) {
        return t.name().toLowerCase(Locale.ROOT);
    }

    private String clean(String reason) {
        String r = reason == null ? "" : reason.strip();
        if (r.isEmpty()) r = plugin.getConfig().getString("settings.default-reason", "No reason given");
        return r.length() > 200 ? r.substring(0, 200) : r;
    }

    private boolean blocked(CommandSender admin, Target t) {
        if (admin instanceof Player p) {
            if (t.uuid() != null && t.uuid().equals(p.getUniqueId())) {
                plugin.messages().send(admin, "self-target");
                return true;
            }
            if (plugin.getConfig().getBoolean("settings.protect-operators", true)
                    && t.uuid() != null && Bukkit.getOfflinePlayer(t.uuid()).isOp()) {
                plugin.messages().send(admin, "protected-target");
                return true;
            }
        }
        return false;
    }

    private void dbError(CommandSender admin, SQLException e) {
        plugin.getLogger().severe("Database error: " + e.getMessage());
        plugin.messages().send(admin, "db-error");
    }

    private void announce(String key, Object... kv) {
        Component msg = plugin.messages().get(key, kv);
        boolean everyone = plugin.getConfig().getBoolean("settings.broadcast-punishments", true);
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (everyone || p.isOp()) p.sendMessage(msg);
        }
        Bukkit.getConsoleSender().sendMessage(msg);
    }

    // ---------- punishments ----------

    public boolean kick(CommandSender admin, Target t, String reasonIn) {
        if (!plugin.security().require(admin, "kick")) return false;
        if (t.online() == null) {
            plugin.messages().send(admin, "player-not-online", "player", t.name());
            return false;
        }
        if (blocked(admin, t)) return false;
        String reason = clean(reasonIn);
        try {
            plugin.database().addPunishment("KICK", t.uuid(), t.name(), admin.getName(), reason, 0);
        } catch (SQLException e) {
            dbError(admin, e);
            return false;
        }
        plugin.database().logAction(uuidOf(admin), admin.getName(), "KICK", t.name(), reason);
        t.online().kick(plugin.messages().get("kick-screen", "reason", reason, "admin", admin.getName()));
        announce("announce-kick", "player", t.name(), "admin", admin.getName(), "reason", reason);
        return true;
    }

    public boolean ban(CommandSender admin, Target t, String reasonIn) {
        if (!plugin.security().require(admin, "ban")) return false;
        if (blocked(admin, t)) return false;
        String reason = clean(reasonIn);
        try {
            if (plugin.database().findActive("BAN", t.uuid(), lower(t)).isPresent()) {
                plugin.messages().send(admin, "already-banned", "player", t.name());
                return false;
            }
            plugin.database().addPunishment("BAN", t.uuid(), t.name(), admin.getName(), reason, 0);
        } catch (SQLException e) {
            dbError(admin, e);
            return false;
        }
        plugin.database().logAction(uuidOf(admin), admin.getName(), "BAN", t.name(), reason);
        if (t.online() != null) {
            t.online().kick(plugin.messages().get("ban-screen", "reason", reason, "admin", admin.getName(), "expires", "never"));
        }
        announce("announce-ban", "player", t.name(), "admin", admin.getName(), "reason", reason, "duration", "permanent");
        return true;
    }

    public boolean unban(CommandSender admin, Target t) {
        if (!plugin.security().require(admin, "unban")) return false;
        try {
            if (plugin.database().revoke("BAN", t.uuid(), lower(t), admin.getName()) == 0) {
                plugin.messages().send(admin, "not-banned", "player", t.name());
                return false;
            }
        } catch (SQLException e) {
            dbError(admin, e);
            return false;
        }
        plugin.database().logAction(uuidOf(admin), admin.getName(), "UNBAN", t.name(), "");
        announce("announce-unban", "player", t.name(), "admin", admin.getName());
        return true;
    }

    /** @param durationMs 0 = permanent */
    public boolean mute(CommandSender admin, Target t, long durationMs, String reasonIn) {
        if (!plugin.security().require(admin, "mute")) return false;
        if (blocked(admin, t)) return false;
        String reason = clean(reasonIn);
        long expires = durationMs == 0 ? 0 : System.currentTimeMillis() + durationMs;
        String dur = TimeUtil.formatDuration(durationMs);
        try {
            if (plugin.database().findActive("MUTE", t.uuid(), lower(t)).isPresent()) {
                plugin.messages().send(admin, "already-muted", "player", t.name());
                return false;
            }
            plugin.database().addPunishment("MUTE", t.uuid(), t.name(), admin.getName(), reason, expires);
        } catch (SQLException e) {
            dbError(admin, e);
            return false;
        }
        plugin.database().logAction(uuidOf(admin), admin.getName(), "MUTE", t.name(), dur + " | " + reason);
        if (t.online() != null) {
            plugin.messages().send(t.online(), "mute-received", "duration", dur, "reason", reason);
        }
        announce("announce-mute", "player", t.name(), "admin", admin.getName(), "reason", reason, "duration", dur);
        return true;
    }

    public boolean unmute(CommandSender admin, Target t) {
        if (!plugin.security().require(admin, "unmute")) return false;
        try {
            if (plugin.database().revoke("MUTE", t.uuid(), lower(t), admin.getName()) == 0) {
                plugin.messages().send(admin, "not-muted", "player", t.name());
                return false;
            }
        } catch (SQLException e) {
            dbError(admin, e);
            return false;
        }
        plugin.database().logAction(uuidOf(admin), admin.getName(), "UNMUTE", t.name(), "");
        announce("announce-unmute", "player", t.name(), "admin", admin.getName());
        return true;
    }

    public boolean warn(CommandSender admin, Target t, String reasonIn) {
        if (!plugin.security().require(admin, "warn")) return false;
        if (blocked(admin, t)) return false;
        String reason = clean(reasonIn);
        try {
            plugin.database().addPunishment("WARN", t.uuid(), t.name(), admin.getName(), reason, 0);
        } catch (SQLException e) {
            dbError(admin, e);
            return false;
        }
        plugin.database().logAction(uuidOf(admin), admin.getName(), "WARN", t.name(), reason);
        if (t.online() != null) {
            plugin.messages().send(t.online(), "warn-received", "reason", reason);
        }
        announce("announce-warn", "player", t.name(), "admin", admin.getName(), "reason", reason);
        return true;
    }

    public Optional<Punishment> activeMute(UUID uuid, String name) throws SQLException {
        return plugin.database().findActive("MUTE", uuid, name.toLowerCase(Locale.ROOT));
    }

    public Optional<Punishment> activeBan(UUID uuid, String name) throws SQLException {
        return plugin.database().findActive("BAN", uuid, name.toLowerCase(Locale.ROOT));
    }

    // ---------- player management ----------

    public boolean freeze(CommandSender admin, Target t) {
        if (!plugin.security().require(admin, "freeze")) return false;
        if (t.online() == null) {
            plugin.messages().send(admin, "player-not-online", "player", t.name());
            return false;
        }
        if (blocked(admin, t)) return false;
        if (!frozen.add(t.uuid())) {
            plugin.messages().send(admin, "already-frozen", "player", t.name());
            return false;
        }
        plugin.database().logAction(uuidOf(admin), admin.getName(), "FREEZE", t.name(), "");
        plugin.messages().send(t.online(), "frozen-notice");
        plugin.messages().send(admin, "freeze-done", "player", t.name());
        return true;
    }

    public boolean unfreeze(CommandSender admin, Target t) {
        if (!plugin.security().require(admin, "unfreeze")) return false;
        if (t.uuid() == null || !frozen.remove(t.uuid())) {
            plugin.messages().send(admin, "not-frozen", "player", t.name());
            return false;
        }
        plugin.database().logAction(uuidOf(admin), admin.getName(), "UNFREEZE", t.name(), "");
        if (t.online() != null) plugin.messages().send(t.online(), "unfrozen-notice");
        plugin.messages().send(admin, "unfreeze-done", "player", t.name());
        return true;
    }

    public boolean setGameMode(CommandSender admin, Player target, GameMode mode) {
        if (!plugin.security().require(admin, "gamemode")) return false;
        target.setGameMode(mode);
        plugin.database().logAction(uuidOf(admin), admin.getName(), "GAMEMODE", target.getName(), mode.name());
        plugin.messages().send(admin, "gamemode-done", "player", target.getName(), "mode", mode.name());
        return true;
    }

    public boolean teleportToPlayer(Player admin, Player target) {
        if (!plugin.security().require(admin, "teleport")) return false;
        if (admin.equals(target)) {
            plugin.messages().send(admin, "self-target");
            return false;
        }
        admin.teleport(target.getLocation());
        plugin.database().logAction(admin.getUniqueId(), admin.getName(), "TELEPORT_PLAYER", target.getName(), "");
        plugin.messages().send(admin, "teleport-done");
        return true;
    }

    public int warnCount(Target t) {
        try {
            return plugin.database().countByType("WARN", t.uuid(), lower(t));
        } catch (SQLException e) {
            return -1;
        }
    }
}
