package net.knightsmp.admintools.service;

import net.knightsmp.admintools.AdminToolsPlugin;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;

public final class TeleportHelper {
    private TeleportHelper() {}

    /**
     * Teleports an admin to a block position. Spectators go to the exact block; others stand on top if the two
     * blocks above are passable, otherwise they are told to use spectator mode (never teleported into a wall).
     */
    public static boolean toBlock(AdminToolsPlugin plugin, Player admin, World world, int x, int y, int z) {
        if (!plugin.security().requireOp(admin, "teleport")) return false;
        if (world == null || !world.isChunkLoaded(x >> 4, z >> 4)) {
            plugin.messages().send(admin, "container-missing");
            return false;
        }
        Location dest;
        if (admin.getGameMode() == GameMode.SPECTATOR) {
            dest = new Location(world, x + 0.5, y, z + 0.5, admin.getLocation().getYaw(), admin.getLocation().getPitch());
        } else {
            Block feet = world.getBlockAt(x, y + 1, z);
            Block head = world.getBlockAt(x, y + 2, z);
            if (!feet.isPassable() || !head.isPassable()) {
                plugin.messages().send(admin, "teleport-unsafe");
                plugin.messages().send(admin, "coords", "x", x, "y", y, "z", z, "world", world.getName());
                return false;
            }
            dest = new Location(world, x + 0.5, y + 1, z + 0.5, admin.getLocation().getYaw(), admin.getLocation().getPitch());
        }
        admin.teleport(dest);
        plugin.messages().send(admin, "teleport-done");
        return true;
    }
}
