package net.knightsmp.admintools.scan;

import org.bukkit.Chunk;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.BlockState;
import org.bukkit.block.Chest;
import org.bukkit.block.Container;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;

/** Admin-only container locator. Loaded chunks only; reads server-side tile entities, sends nothing to clients. */
public final class ChestScanner {
    public record ContainerHit(UUID worldId, String worldName, Material material, ContainerCategory category,
                               int x, int y, int z, double distance, int usedSlots, int totalSlots) {}

    public record Result(List<ContainerHit> hits, int radius, boolean truncated) {}

    private ChestScanner() {}

    public static Result scan(Location center, int radius, int maxResults) {
        World w = center.getWorld();
        double r2 = (double) radius * radius;
        List<ContainerHit> hits = new ArrayList<>();
        int minCx = (center.getBlockX() - radius) >> 4, maxCx = (center.getBlockX() + radius) >> 4;
        int minCz = (center.getBlockZ() - radius) >> 4, maxCz = (center.getBlockZ() + radius) >> 4;
        for (int cx = minCx; cx <= maxCx; cx++) {
            for (int cz = minCz; cz <= maxCz; cz++) {
                if (!w.isChunkLoaded(cx, cz)) continue;   // never force-load
                Chunk chunk = w.getChunkAt(cx, cz);       // already loaded, so this does not load anything
                for (BlockState state : chunk.getTileEntities(false)) {
                    if (!(state instanceof Container container)) continue;
                    double dx = state.getX() - center.getX(), dy = state.getY() - center.getY(), dz = state.getZ() - center.getZ();
                    double d2 = dx * dx + dy * dy + dz * dz;
                    if (d2 > r2) continue;
                    // For double chests count only this half so each half is listed once with its own contents.
                    Inventory inv = container instanceof Chest chest ? chest.getBlockInventory() : container.getInventory();
                    int used = 0;
                    for (ItemStack it : inv.getContents()) {
                        if (it != null && !it.getType().isAir()) used++;
                    }
                    Material type = state.getType();
                    hits.add(new ContainerHit(w.getUID(), w.getName(), type, ContainerCategory.of(type),
                            state.getX(), state.getY(), state.getZ(), Math.sqrt(d2), used, inv.getSize()));
                }
            }
        }
        hits.sort(Comparator.comparingDouble(ContainerHit::distance));
        boolean truncated = false;
        if (hits.size() > maxResults) {
            hits = new ArrayList<>(hits.subList(0, maxResults));
            truncated = true;
        }
        return new Result(hits, radius, truncated);
    }
}
