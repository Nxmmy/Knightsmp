package net.knightsmp.admintools.scan;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Admin-only ore search. Reads block data directly from the server world (no packets are sent, no client is
 * ever told about hidden blocks), only touches ALREADY LOADED chunks (never forces chunk loads) and runs on
 * the main thread because it must read live block data.
 */
public final class OreScanner {
    private static final int HARD_CAP = 20_000;

    public record OreHit(OreType type, Material material, int x, int y, int z, double distance) {}

    public record Result(UUID worldId, String worldName, int cx, int cy, int cz, int radius, boolean hiddenOnly,
                         List<OreHit> hits, Map<OreType, Integer> counts, boolean truncated) {}

    private OreScanner() {}

    public static Result scan(Location center, int radius, boolean hiddenOnly, int maxResults) {
        World w = center.getWorld();
        int cx = center.getBlockX(), cy = center.getBlockY(), cz = center.getBlockZ();
        int minY = Math.max(w.getMinHeight(), cy - radius);
        int maxY = Math.min(w.getMaxHeight() - 1, cy + radius);
        List<OreHit> hits = new ArrayList<>();
        boolean capped = false;
        outer:
        for (int x = cx - radius; x <= cx + radius; x++) {
            for (int z = cz - radius; z <= cz + radius; z++) {
                if (!w.isChunkLoaded(x >> 4, z >> 4)) continue;
                for (int y = minY; y <= maxY; y++) {
                    OreType type = OreType.of(w.getType(x, y, z));
                    if (type == null) continue;
                    if (hiddenOnly && exposed(w, x, y, z)) continue;
                    double dx = x - cx, dy = y - cy, dz = z - cz;
                    hits.add(new OreHit(type, w.getType(x, y, z), x, y, z, Math.sqrt(dx * dx + dy * dy + dz * dz)));
                    if (hits.size() >= HARD_CAP) {
                        capped = true;
                        break outer;
                    }
                }
            }
        }
        hits.sort(Comparator.comparingDouble(OreHit::distance));
        Map<OreType, Integer> counts = new EnumMap<>(OreType.class);
        for (OreHit h : hits) counts.merge(h.type(), 1, Integer::sum);
        boolean truncated = capped;
        if (hits.size() > maxResults) {
            hits = new ArrayList<>(hits.subList(0, maxResults));
            truncated = true;
        }
        return new Result(w.getUID(), w.getName(), cx, cy, cz, radius, hiddenOnly, hits, counts, truncated);
    }

    /** An ore is "exposed" if any face touches a non-occluding block (air, water, lava, glass, torch...). */
    private static boolean exposed(World w, int x, int y, int z) {
        int[][] d = {{1, 0, 0}, {-1, 0, 0}, {0, 1, 0}, {0, -1, 0}, {0, 0, 1}, {0, 0, -1}};
        for (int[] o : d) {
            int nx = x + o[0], ny = y + o[1], nz = z + o[2];
            if (ny < w.getMinHeight() || ny >= w.getMaxHeight()) continue;
            if (!w.isChunkLoaded(nx >> 4, nz >> 4)) continue;   // unknown neighbour: do not force-load it
            if (!w.getType(nx, ny, nz).isOccluding()) return true;
        }
        return false;
    }
}
