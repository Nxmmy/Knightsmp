package net.knightsmp.admintools;

import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.entity.Player;

import java.util.UUID;

/**
 * Single choke point for authorization. Every command, GUI open, GUI click and service action calls
 * into here. Authorization is Player#isOp() ONLY - never permission nodes - so permission plugins
 * cannot grant access. The server console is trusted. Everything else (command blocks, RCON, etc.) is denied.
 */
public final class Security {
    private final AdminToolsPlugin plugin;

    public Security(AdminToolsPlugin plugin) {
        this.plugin = plugin;
    }

    public boolean isAdmin(CommandSender sender) {
        if (sender instanceof ConsoleCommandSender) {
            return true;
        }
        return sender instanceof Player p && p.isOp();
    }

    /** Returns true if allowed. If denied: tells the sender, logs to the DB and console, alerts online OPs. */
    public boolean require(CommandSender sender, String action) {
        if (isAdmin(sender)) {
            return true;
        }
        UUID id = sender instanceof Player p ? p.getUniqueId() : null;
        plugin.messages().send(sender, "no-permission");
        plugin.database().logAction(id, sender.getName(), "ACCESS_DENIED", "-", action);
        plugin.getLogger().warning("DENIED non-OP " + sender.getName() + " attempted: " + action);
        for (Player online : Bukkit.getOnlinePlayers()) {
            if (online.isOp() && !online.equals(sender)) {
                plugin.messages().send(online, "denied-alert", "player", sender.getName(), "action", action);
            }
        }
        return false;
    }

    public boolean requireOp(Player player, String action) {
        return require(player, action);
    }
}
