package net.knightsmp.admintools.db;

import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.UUID;
import java.util.logging.Logger;

/**
 * SQLite persistence. Uses the sqlite-jdbc driver bundled with the Paper server (no shading).
 * One connection, all methods synchronized. Writes are synchronous on purpose so that a ban/mute is
 * visible to the very next read (login/chat checks) - the DB is a small local file in WAL mode.
 */
public final class Database implements AutoCloseable {
    private final Connection conn;
    private final Logger log;

    public Database(Path file, Logger log) throws SQLException {
        this.log = log;
        try {
            Class.forName("org.sqlite.JDBC");
        } catch (ClassNotFoundException e) {
            throw new SQLException("SQLite JDBC driver (org.sqlite.JDBC) not found on the server classpath", e);
        }
        conn = DriverManager.getConnection("jdbc:sqlite:" + file.toAbsolutePath());
        try (Statement st = conn.createStatement()) {
            st.execute("PRAGMA journal_mode=WAL");
            st.execute("PRAGMA synchronous=NORMAL");
            st.execute("PRAGMA busy_timeout=5000");
            st.execute("""
                CREATE TABLE IF NOT EXISTS staff_log(
                  id INTEGER PRIMARY KEY AUTOINCREMENT,
                  ts INTEGER NOT NULL,
                  admin_uuid TEXT,
                  admin_name TEXT NOT NULL,
                  action TEXT NOT NULL,
                  target TEXT,
                  details TEXT)""");
            st.execute("""
                CREATE TABLE IF NOT EXISTS punishments(
                  id INTEGER PRIMARY KEY AUTOINCREMENT,
                  ts INTEGER NOT NULL,
                  type TEXT NOT NULL,
                  target_uuid TEXT,
                  target_name TEXT NOT NULL,
                  target_name_lower TEXT NOT NULL,
                  admin_name TEXT NOT NULL,
                  reason TEXT,
                  expires INTEGER NOT NULL DEFAULT 0,
                  active INTEGER NOT NULL DEFAULT 0,
                  removed_by TEXT,
                  removed_ts INTEGER)""");
            st.execute("""
                CREATE TABLE IF NOT EXISTS confiscations(
                  id INTEGER PRIMARY KEY AUTOINCREMENT,
                  ts INTEGER NOT NULL,
                  admin_uuid TEXT,
                  admin_name TEXT NOT NULL,
                  target_uuid TEXT NOT NULL,
                  target_name TEXT NOT NULL,
                  slot_label TEXT,
                  item_type TEXT NOT NULL,
                  amount INTEGER NOT NULL,
                  item_data BLOB)""");
            st.execute("CREATE INDEX IF NOT EXISTS idx_pun_uuid ON punishments(target_uuid, type, active)");
            st.execute("CREATE INDEX IF NOT EXISTS idx_pun_name ON punishments(target_name_lower, type, active)");
            st.execute("CREATE INDEX IF NOT EXISTS idx_log_ts ON staff_log(ts)");
        }
    }

    private static String str(UUID u) {
        return u == null ? null : u.toString();
    }

    /** Never throws: a failing audit write must not break the action, but is reported loudly to the console. */
    public synchronized void logAction(UUID adminUuid, String adminName, String action, String target, String details) {
        try (PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO staff_log(ts,admin_uuid,admin_name,action,target,details) VALUES(?,?,?,?,?,?)")) {
            ps.setLong(1, System.currentTimeMillis());
            ps.setString(2, str(adminUuid));
            ps.setString(3, adminName);
            ps.setString(4, action);
            ps.setString(5, target);
            ps.setString(6, details);
            ps.executeUpdate();
        } catch (SQLException e) {
            log.severe("FAILED to write staff log [" + adminName + " " + action + " " + target + " " + details + "]: " + e.getMessage());
        }
    }

    public synchronized List<LogEntry> recentLogs(int limit) throws SQLException {
        List<LogEntry> out = new ArrayList<>();
        try (PreparedStatement ps = conn.prepareStatement(
                "SELECT id,ts,admin_uuid,admin_name,action,target,details FROM staff_log ORDER BY id DESC LIMIT ?")) {
            ps.setInt(1, limit);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    out.add(new LogEntry(rs.getLong(1), rs.getLong(2), rs.getString(3), rs.getString(4),
                            rs.getString(5), rs.getString(6), rs.getString(7)));
                }
            }
        }
        return out;
    }

    /** BAN and MUTE are stored active; KICK and WARN are history-only. */
    public synchronized long addPunishment(String type, UUID targetUuid, String targetName, String adminName,
                                           String reason, long expires) throws SQLException {
        boolean active = type.equals("BAN") || type.equals("MUTE");
        try (PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO punishments(ts,type,target_uuid,target_name,target_name_lower,admin_name,reason,expires,active) "
                        + "VALUES(?,?,?,?,?,?,?,?,?)", Statement.RETURN_GENERATED_KEYS)) {
            ps.setLong(1, System.currentTimeMillis());
            ps.setString(2, type);
            ps.setString(3, str(targetUuid));
            ps.setString(4, targetName);
            ps.setString(5, targetName.toLowerCase(Locale.ROOT));
            ps.setString(6, adminName);
            ps.setString(7, reason);
            ps.setLong(8, expires);
            ps.setInt(9, active ? 1 : 0);
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                return keys.next() ? keys.getLong(1) : -1;
            }
        }
    }

    private static final String MATCH_TARGET =
            "((target_uuid IS NOT NULL AND target_uuid = ?) OR target_name_lower = ?)";

    public synchronized Optional<Punishment> findActive(String type, UUID uuid, String nameLower) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement(
                "SELECT * FROM punishments WHERE type=? AND active=1 AND (expires=0 OR expires>?) AND " + MATCH_TARGET
                        + " ORDER BY id DESC LIMIT 1")) {
            ps.setString(1, type);
            ps.setLong(2, System.currentTimeMillis());
            ps.setString(3, str(uuid));
            ps.setString(4, nameLower);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? Optional.of(map(rs)) : Optional.empty();
            }
        }
    }

    /** @return number of rows revoked */
    public synchronized int revoke(String type, UUID uuid, String nameLower, String removedBy) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement(
                "UPDATE punishments SET active=0, removed_by=?, removed_ts=? WHERE type=? AND active=1 AND " + MATCH_TARGET)) {
            ps.setString(1, removedBy);
            ps.setLong(2, System.currentTimeMillis());
            ps.setString(3, type);
            ps.setString(4, str(uuid));
            ps.setString(5, nameLower);
            return ps.executeUpdate();
        }
    }

    public synchronized List<Punishment> history(UUID uuid, String nameLower, int limit) throws SQLException {
        return query("SELECT * FROM punishments WHERE " + MATCH_TARGET + " ORDER BY id DESC LIMIT ?",
                str(uuid), nameLower, limit);
    }

    public synchronized List<Punishment> recentPunishments(int limit) throws SQLException {
        return query("SELECT * FROM punishments ORDER BY id DESC LIMIT ?", limit);
    }

    public synchronized int countByType(String type, UUID uuid, String nameLower) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement(
                "SELECT COUNT(*) FROM punishments WHERE type=? AND " + MATCH_TARGET)) {
            ps.setString(1, type);
            ps.setString(2, str(uuid));
            ps.setString(3, nameLower);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getInt(1) : 0;
            }
        }
    }

    private List<Punishment> query(String sql, Object... params) throws SQLException {
        List<Punishment> out = new ArrayList<>();
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            for (int i = 0; i < params.length; i++) {
                ps.setObject(i + 1, params[i]);
            }
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) out.add(map(rs));
            }
        }
        return out;
    }

    private static Punishment map(ResultSet rs) throws SQLException {
        return new Punishment(rs.getLong("id"), rs.getLong("ts"), rs.getString("type"), rs.getString("target_uuid"),
                rs.getString("target_name"), rs.getString("admin_name"), rs.getString("reason"),
                rs.getLong("expires"), rs.getInt("active") == 1);
    }

    public synchronized void addConfiscation(UUID adminUuid, String adminName, UUID targetUuid, String targetName,
                                             String slotLabel, String itemType, int amount, byte[] itemData) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO confiscations(ts,admin_uuid,admin_name,target_uuid,target_name,slot_label,item_type,amount,item_data) "
                        + "VALUES(?,?,?,?,?,?,?,?,?)")) {
            ps.setLong(1, System.currentTimeMillis());
            ps.setString(2, str(adminUuid));
            ps.setString(3, adminName);
            ps.setString(4, targetUuid.toString());
            ps.setString(5, targetName);
            ps.setString(6, slotLabel);
            ps.setString(7, itemType);
            ps.setInt(8, amount);
            ps.setBytes(9, itemData);
            ps.executeUpdate();
        }
    }

    @Override
    public synchronized void close() {
        try {
            conn.close();
        } catch (SQLException ignored) {
        }
    }
}
