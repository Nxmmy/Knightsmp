package net.knightsmp.admintools.db;

public record Punishment(long id, long ts, String type, String targetUuid, String targetName,
                         String adminName, String reason, long expires, boolean active) {
    /** Currently in force (BAN/MUTE only ever have active=true). */
    public boolean isLive() {
        return active && (expires == 0 || expires > System.currentTimeMillis());
    }
}
