package net.knightsmp.admintools.gui;

import net.knightsmp.admintools.AdminToolsPlugin;
import org.bukkit.Material;
import org.bukkit.entity.Player;

public final class XrayMenu extends Menu {

    public XrayMenu(AdminToolsPlugin plugin, Player viewer, Menu parent) {
        super(plugin, viewer, parent);
    }

    @Override
    protected String title() {
        return "<dark_gray>X-Ray Inspection";
    }

    @Override
    protected int rows() {
        return 3;
    }

    @Override
    protected void build() {
        var cfg = plugin.getConfig();
        set(11, Items.make(Material.DIAMOND_PICKAXE, "<aqua>Ore Inspection",
                "<gray>Radius: <white>" + cfg.getInt("settings.ore-scan.radius", 16),
                "<gray>Loaded chunks around you only.", "<yellow>Click to scan"),
                () -> goTo(new OreMenu(plugin, viewer, this)));
        set(15, Items.make(Material.CHEST, "<gold>Chest Inspection",
                "<gray>Radius: <white>" + cfg.getInt("settings.chest-scan.radius", 48),
                "<gray>Loaded chunks around you only.", "<yellow>Click to scan"),
                () -> goTo(new ChestListMenu(plugin, viewer, this)));
        set(22, Items.make(Material.ARROW, "<yellow>« Back"), this::back);
    }
}
