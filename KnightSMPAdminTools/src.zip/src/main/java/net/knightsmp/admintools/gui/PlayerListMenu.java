package net.knightsmp.admintools.gui;

import net.knightsmp.admintools.AdminToolsPlugin;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.Comparator;
import java.util.List;
import java.util.function.BiFunction;

/** Online player picker. The factory builds the menu to open for the chosen player; it receives this list as parent. */
public final class PlayerListMenu extends PagedMenu<Player> {
    private final String heading;
    private final BiFunction<Menu, Player, Menu> factory;

    public PlayerListMenu(AdminToolsPlugin plugin, Player viewer, Menu parent, String heading,
                          BiFunction<Menu, Player, Menu> factory) {
        super(plugin, viewer, parent);
        this.heading = heading;
        this.factory = factory;
    }

    @Override
    protected String title() {
        return "<dark_gray>" + Items.esc(heading) + " <gray>» <white>Players";
    }

    @Override
    protected List<Player> load() {
        return Bukkit.getOnlinePlayers().stream()
                .sorted(Comparator.comparing(p -> p.getName().toLowerCase()))
                .map(p -> (Player) p).toList();
    }

    @Override
    protected ItemStack render(Player p) {
        return Items.head(p, "<aqua>" + Items.esc(p.getName()),
                "<gray>Health: <white>" + String.format("%.1f", p.getHealth()),
                "<gray>Mode: <white>" + p.getGameMode().name(),
                "<gray>World: <white>" + Items.esc(p.getWorld().getName()),
                "", "<yellow>Click to select");
    }

    @Override
    protected void onSelect(Player p) {
        if (!p.isOnline()) {
            reload();
            return;
        }
        Menu next = factory.apply(this, p);
        if (next != this) goTo(next);
    }

    @Override
    protected void footer() {
        set(46, Items.make(org.bukkit.Material.SUNFLOWER, "<green>Refresh list"), this::reload);
    }
}
