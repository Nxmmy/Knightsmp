package net.knightsmp.admintools.db;

public record LogEntry(long id, long ts, String adminUuid, String adminName, String action, String target, String details) {}
