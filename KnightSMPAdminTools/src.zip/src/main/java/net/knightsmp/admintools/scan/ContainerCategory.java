package net.knightsmp.admintools.scan;

import org.bukkit.Material;

public enum ContainerCategory {
    CHEST("Chests"), BARREL("Barrels"), SHULKER("Shulker boxes"), OTHER("Other (hoppers, furnaces...)");

    private final String display;

    ContainerCategory(String display) {
        this.display = display;
    }

    public String display() {
        return display;
    }

    public static ContainerCategory of(Material m) {
        if (m == Material.CHEST || m == Material.TRAPPED_CHEST) return CHEST;
        if (m == Material.BARREL) return BARREL;
        if (m.name().endsWith("SHULKER_BOX")) return SHULKER;
        return OTHER;
    }
}
