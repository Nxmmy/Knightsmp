package net.knightsmp.admintools;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.ArrayList;
import java.util.List;

/** Config-driven MiniMessage messages. Dynamic values are always inserted as unparsed text (no tag injection). */
public final class Messages {
    private static final MiniMessage MM = MiniMessage.miniMessage();
    private final AdminToolsPlugin plugin;

    public Messages(AdminToolsPlugin plugin) {
        this.plugin = plugin;
    }

    /** key/value pairs: get("x", "player", name, "reason", r) */
    public Component get(String key, Object... kv) {
        FileConfiguration cfg = plugin.getConfig();
        String raw = cfg.getString("messages." + key);
        if (raw == null) {
            raw = "<prefix><red>Missing message key: " + key;
        }
        List<TagResolver> resolvers = new ArrayList<>();
        resolvers.add(Placeholder.parsed("prefix", cfg.getString("settings.prefix", "")));
        for (int i = 0; i + 1 < kv.length; i += 2) {
            resolvers.add(Placeholder.unparsed(String.valueOf(kv[i]), String.valueOf(kv[i + 1])));
        }
        return MM.deserialize(raw, TagResolver.resolver(resolvers));
    }

    public void send(CommandSender to, String key, Object... kv) {
        to.sendMessage(get(key, kv));
    }
}
