package net.knightsmp.admintools;

import net.knightsmp.admintools.command.AdminCommands;
import net.knightsmp.admintools.db.Database;
import net.knightsmp.admintools.gui.Menu;
import net.knightsmp.admintools.gui.MenuListener;
import net.knightsmp.admintools.listener.GuardListener;
import net.knightsmp.admintools.service.ModerationService;
import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.nio.file.Files;
import java.util.List;

public final class AdminToolsPlugin extends JavaPlugin {

    private static final List<String> COMMANDS = List.of(
            "admin", "inventorycheck", "kick", "ban", "unban", "mute", "unmute", "warn", "history", "freeze", "unfreeze");

    private Database database;
    private Messages messages;
    private Security security;
    private ModerationService moderation;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        messages = new Messages(this);
        try {
            Files.createDirectories(getDataFolder().toPath());
            database = new Database(getDataFolder().toPath().resolve("staff.db"), getLogger());
        } catch (Exception ex) {
            getLogger().severe("Could not open SQLite database: " + ex.getMessage());
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        security = new Security(this);
        moderation = new ModerationService(this);

        getServer().getPluginManager().registerEvents(new GuardListener(this), this);
        getServer().getPluginManager().registerEvents(new MenuListener(this), this);

        AdminCommands handler = new AdminCommands(this);
        for (String name : COMMANDS) {
            PluginCommand cmd = getCommand(name);
            if (cmd == null) {
                getLogger().warning("Command missing from plugin.yml: " + name);
                continue;
            }
            cmd.setExecutor(handler);
            cmd.setTabCompleter(handler);
        }
        getLogger().info("KnightSMPAdminTools enabled. All features are OP-only.");
    }

    @Override
    public void onDisable() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.getOpenInventory().getTopInventory().getHolder(false) instanceof Menu) {
                p.closeInventory();
            }
        }
        if (database != null) {
            database.close();
        }
    }

    public void reloadAll() {
        reloadConfig();
    }

    public Database database() { return database; }
    public Messages messages() { return messages; }
    public Security security() { return security; }
    public ModerationService moderation() { return moderation; }
}
