package net.knightsmp.admintools.gui;

import net.knightsmp.admintools.AdminToolsPlugin;
import net.knightsmp.admintools.scan.ChestScanner;
import net.knightsmp.admintools.scan.ChestScanner.ContainerHit;
import net.knightsmp.admintools.scan.ContainerCategory;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

public final class ChestListMenu extends PagedMenu<ContainerHit> {
    private ChestScanner.Result result;
    private ContainerCategory filter = null;

    public ChestListMenu(AdminToolsPlugin plugin, Player viewer, Menu parent) {
        super(plugin, viewer, parent);
    }

    @Override
    protected String title() {
        return "<dark_gray>X-Ray <gray>» <white>Containers <gray>(" + (filter == null ? "all" : filter.name().toLowerCase()) + ")";
    }

    private void rescan() {
        var cfg = plugin.getConfig();
        int max = cfg.getInt("settings.chest-scan.max-radius", 96);
        int radius = Math.max(1, Math.min(cfg.getInt("settings.chest-scan.radius", 48), max));
        result = ChestScanner.scan(viewer.getLocation(), radius, cfg.getInt("settings.chest-scan.max-results", 300));
        plugin.database().logAction(viewer.getUniqueId(), viewer.getName(), "CHEST_SCAN", viewer.getWorld().getName(),
                "center=" + viewer.getLocation().getBlockX() + "," + viewer.getLocation().getBlockY() + ","
                        + viewer.getLocation().getBlockZ() + " r=" + radius + " found=" + result.hits().size()
                        + (result.truncated() ? "+" : ""));
        plugin.messages().send(viewer, "scan-done-chest", "count", result.hits().size(),
                "note", result.truncated() ? " (truncated)" : "");
    }

    @Override
    protected List<ContainerHit> load() {
        if (result == null) rescan();
        if (filter == null) return result.hits();
        List<ContainerHit> out = new ArrayList<>();
        for (ContainerHit h : result.hits()) if (h.category() == filter) out.add(h);
        return out;
    }

    @Override
    protected ItemStack render(ContainerHit h) {
        Material icon = h.material().isItem() ? h.material() : Material.CHEST;
        return Items.make(icon, 1, "<gold>" + h.material().name() + " <gray>at <white>" + h.x() + " " + h.y() + " " + h.z(),
                List.of("<gray>Contents: <white>" + h.usedSlots() + "<gray>/<white>" + h.totalSlots() + " <gray>slots used",
                        "<gray>Distance: <white>" + String.format("%.1f", h.distance()) + " blocks",
                        "<gray>World: <white>" + Items.esc(h.worldName()), "", "<yellow>Click to inspect contents"));
    }

    @Override
    protected void onSelect(ContainerHit h) {
        goTo(new ChestViewMenu(plugin, viewer, this, h));
    }

    @Override
    protected void footer() {
        set(46, Items.make(Material.HOPPER, "<aqua>Filter: <white>" + (filter == null ? "All" : filter.display()),
                "<yellow>Click to cycle"), () -> {
            ContainerCategory[] all = ContainerCategory.values();
            if (filter == null) filter = all[0];
            else if (filter.ordinal() == all.length - 1) filter = null;
            else filter = all[filter.ordinal() + 1];
            page = 0;
            reload();
        });
        set(47, Items.make(Material.SPYGLASS, "<green>Rescan here"), () -> {
            rescan();
            page = 0;
            reload();
        });
    }
}
