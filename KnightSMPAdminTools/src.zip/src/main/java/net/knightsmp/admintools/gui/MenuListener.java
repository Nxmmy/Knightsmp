package net.knightsmp.admintools.gui;

import net.knightsmp.admintools.AdminToolsPlugin;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.inventory.Inventory;

/**
 * Cancels EVERY click/drag while one of our menus is the top inventory (including shift-click from the player's
 * own inventory, number keys, creative clicks, double-click collect). Re-checks OP on every single click, so a
 * de-opped player's open menu is dead on the next click.
 */
public final class MenuListener implements Listener {
    private final AdminToolsPlugin plugin;

    public MenuListener(AdminToolsPlugin plugin) {
        this.plugin = plugin;
    }

    private static Menu menuOf(Inventory top) {
        return top.getHolder(false) instanceof Menu m ? m : null;
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onClick(InventoryClickEvent e) {
        Inventory top = e.getView().getTopInventory();
        Menu menu = menuOf(top);
        if (menu == null) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (!plugin.security().requireOp(p, "gui-click:" + menu.getClass().getSimpleName())) {
            Bukkit.getScheduler().runTask(plugin, p::closeInventory);
            return;
        }
        if (!menu.isViewer(p)) return;
        if (e.getClickedInventory() == null || e.getClickedInventory() != top) return;
        try {
            menu.handleClick(e.getSlot(), e.getClick());
        } catch (RuntimeException ex) {
            plugin.getLogger().severe("GUI error in " + menu.getClass().getSimpleName() + ": " + ex);
            ex.printStackTrace();
            plugin.messages().send(p, "internal-error");
        }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onDrag(InventoryDragEvent e) {
        if (menuOf(e.getView().getTopInventory()) != null) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onOpen(InventoryOpenEvent e) {
        if (menuOf(e.getInventory()) == null) return;
        if (!(e.getPlayer() instanceof Player p) || !plugin.security().requireOp(p, "gui-open")) {
            e.setCancelled(true);
        }
    }
}
