package net.knightsmp.admintools.gui;

import net.knightsmp.admintools.AdminToolsPlugin;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.Map;

/**
 * Base class for every admin menu. Menus are identified by being the InventoryHolder of their inventory, so
 * MenuListener can cancel ALL interaction with them. Menus only ever display CLONES of items, so nothing in
 * a menu can be taken or duplicated by the viewer.
 */
public abstract class Menu implements InventoryHolder {
    protected final AdminToolsPlugin plugin;
    protected final Player viewer;
    protected final Menu parent;
    private final Map<Integer, Runnable> actions = new HashMap<>();
    private Inventory inventory;

    protected Menu(AdminToolsPlugin plugin, Player viewer, Menu parent) {
        this.plugin = plugin;
        this.viewer = viewer;
        this.parent = parent;
    }

    /** MiniMessage title. */
    protected abstract String title();

    protected int rows() {
        return 6;
    }

    protected abstract void build();

    protected void beforeOpen() {}

    protected void afterOpen() {}

    /** Server-side OP check happens here on every open. */
    public boolean open() {
        if (!plugin.security().requireOp(viewer, "open-gui:" + getClass().getSimpleName())) return false;
        beforeOpen();
        inventory = Bukkit.createInventory(this, rows() * 9, Items.c(title()));
        render();
        viewer.openInventory(inventory);
        afterOpen();
        return true;
    }

    private void render() {
        actions.clear();
        inventory.clear();
        for (int i = 0; i < inventory.getSize(); i++) inventory.setItem(i, Items.filler());
        build();
    }

    public void refresh() {
        if (inventory != null) render();
    }

    protected void set(int slot, ItemStack item) {
        inventory.setItem(slot, item);
    }

    protected void set(int slot, ItemStack item, Runnable action) {
        inventory.setItem(slot, item);
        actions.put(slot, action);
    }

    protected void goTo(Menu next) {
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (viewer.isOnline()) next.open();
        });
    }

    protected void back() {
        if (parent != null) goTo(parent);
        else close();
    }

    protected void close() {
        Bukkit.getScheduler().runTask(plugin, viewer::closeInventory);
    }

    public boolean isViewer(Player p) {
        return viewer.getUniqueId().equals(p.getUniqueId());
    }

    public void handleClick(int slot, ClickType type) {
        if (type != ClickType.LEFT && type != ClickType.RIGHT) return;
        Runnable r = actions.get(slot);
        if (r != null) r.run();
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }
}
