package net.knightsmp.admintools.gui;

import net.knightsmp.admintools.AdminToolsPlugin;
import net.knightsmp.admintools.scan.OreScanner;
import net.knightsmp.admintools.scan.OreScanner.OreHit;
import net.knightsmp.admintools.scan.OreType;
import net.knightsmp.admintools.service.TeleportHelper;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

public final class OreMenu extends PagedMenu<OreHit> {
    private OreScanner.Result result;
    private OreType filter = null;   // null = all
    private boolean hiddenOnly;

    public OreMenu(AdminToolsPlugin plugin, Player viewer, Menu parent) {
        super(plugin, viewer, parent);
        this.hiddenOnly = plugin.getConfig().getBoolean("settings.ore-scan.hidden-only", true);
    }

    @Override
    protected String title() {
        return "<dark_gray>X-Ray <gray>» <white>Ores <gray>(" + (filter == null ? "all" : filter.display()) + ")";
    }

    private void rescan() {
        var cfg = plugin.getConfig();
        int max = cfg.getInt("settings.ore-scan.max-radius", 32);
        int radius = Math.max(1, Math.min(cfg.getInt("settings.ore-scan.radius", 16), max));
        result = OreScanner.scan(viewer.getLocation(), radius, hiddenOnly, cfg.getInt("settings.ore-scan.max-results", 500));
        plugin.database().logAction(viewer.getUniqueId(), viewer.getName(), "ORE_INSPECT", result.worldName(),
                "center=" + result.cx() + "," + result.cy() + "," + result.cz() + " r=" + radius
                        + " hiddenOnly=" + hiddenOnly + " found=" + result.hits().size() + (result.truncated() ? "+" : ""));
        plugin.messages().send(viewer, "scan-done-ore", "count", result.hits().size(),
                "note", result.truncated() ? " (truncated)" : "");
    }

    @Override
    protected List<OreHit> load() {
        if (result == null) rescan();
        if (filter == null) return result.hits();
        List<OreHit> out = new ArrayList<>();
        for (OreHit h : result.hits()) if (h.type() == filter) out.add(h);
        return out;
    }

    @Override
    protected ItemStack render(OreHit h) {
        return Items.make(h.material(), 1, "<aqua>" + h.type().display() + " <gray>at <white>" + h.x() + " " + h.y() + " " + h.z(),
                List.of("<gray>Distance: <white>" + String.format("%.1f", h.distance()) + " blocks",
                        "<gray>World: <white>" + Items.esc(result.worldName()), "", "<yellow>Click to teleport"));
    }

    @Override
    protected void onSelect(OreHit h) {
        if (!plugin.security().requireOp(viewer, "ore-teleport")) return;
        var world = Bukkit.getWorld(result.worldId());
        if (TeleportHelper.toBlock(plugin, viewer, world, h.x(), h.y(), h.z())) {
            plugin.database().logAction(viewer.getUniqueId(), viewer.getName(), "ORE_TELEPORT", result.worldName(),
                    h.type().name() + " at " + h.x() + "," + h.y() + "," + h.z());
        }
    }

    @Override
    protected void footer() {
        List<String> lore = new ArrayList<>();
        lore.add("<gray>Current: <white>" + (filter == null ? "All ores" : filter.display()));
        for (OreType t : OreType.values()) {
            int n = result.counts().getOrDefault(t, 0);
            if (n > 0) lore.add("<dark_gray>" + t.display() + ": <white>" + n);
        }
        lore.add("<yellow>Click to cycle filter");
        set(46, Items.make(filter == null ? Material.HOPPER : filter.icon(), 1, "<aqua>Filter by ore type", lore), () -> {
            OreType[] all = OreType.values();
            if (filter == null) filter = all[0];
            else if (filter.ordinal() == all.length - 1) filter = null;
            else filter = all[filter.ordinal() + 1];
            page = 0;
            reload();
        });
        set(47, Items.make(Material.SPYGLASS, "<green>Rescan here", "<gray>Scans around your current position"), () -> {
            rescan();
            page = 0;
            reload();
        });
        set(50, Items.make(hiddenOnly ? Material.LIME_DYE : Material.GRAY_DYE,
                "<white>Hidden ores only: " + (hiddenOnly ? "<green>ON" : "<red>OFF"),
                "<gray>ON = ores fully enclosed by solid blocks", "<yellow>Click to toggle + rescan"), () -> {
            hiddenOnly = !hiddenOnly;
            rescan();
            page = 0;
            reload();
        });
    }
}
