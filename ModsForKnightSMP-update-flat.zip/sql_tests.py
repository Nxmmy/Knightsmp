"""Runs the plugin's REAL SQL statements (parsed out of Sql.java) against SQLite and checks the economy invariants.
Usage: python3 sql_tests.py path/to/Sql.java
"""
import re, sqlite3, sys, os, tempfile, threading, uuid, time

src = open(sys.argv[1] if len(sys.argv) > 1 else "Sql.java").read()
SQL = dict(re.findall(r'public static final String (\w+) = "((?:[^"\\]|\\.)*)";', src))
declared = src.count("public static final String")
assert len(SQL) == declared, f"parsed {len(SQL)} of {declared} statements"

passed = failed = 0
def check(name, cond, detail=""):
    global passed, failed
    if cond: passed += 1; print(f"  PASS  {name}")
    else: failed += 1; print(f"  FAIL  {name} {detail}")

def new_db(path=None):
    path = path or tempfile.mktemp(suffix=".db")
    c = sqlite3.connect(path, isolation_level=None)
    for k in ("CREATE_ACCOUNTS","CREATE_TX","CREATE_TX_INDEX","CREATE_KITS","CREATE_MARKET","CREATE_META"): c.execute(SQL[k])
    return c, path
def add(c, name, dollars=0, bounty=0):
    u = str(uuid.uuid4()); c.execute(SQL["INSERT_ACCOUNT"], (u, name, dollars))
    if bounty: c.execute(SQL["BOUNTY_SET"], (bounty, u))
    return u
def bal(c, u): return c.execute("SELECT dollars FROM accounts WHERE uuid=?", (u,)).fetchone()[0]
def bnty(c, u): return c.execute("SELECT bounty FROM accounts WHERE uuid=?", (u,)).fetchone()[0]

def move(c, u, delta, kind="TEST", extra=None):
    """Mirror of EconomyManager.commit for one change: conditional update + history row + extra, all-or-nothing."""
    c.execute("BEGIN")
    try:
        n = c.execute(SQL["CREDIT"], (delta, u)).rowcount if delta >= 0 else c.execute(SQL["DEBIT"], (-delta, u, -delta)).rowcount
        if n != 1: c.execute("ROLLBACK"); return False
        c.execute(SQL["TX_INSERT"], (int(time.time()*1000), u, None, "USD", delta, kind))
        if extra and not extra(c): c.execute("ROLLBACK"); return False
        c.execute("COMMIT"); return True
    except Exception:
        c.execute("ROLLBACK"); return False

print("== accounts / balances")
c, path = new_db()
a = add(c, "alice", 150)
check("starting balance stored", bal(c, a) == 150)
check("INSERT OR IGNORE does not duplicate/reset an account", (c.execute(SQL["INSERT_ACCOUNT"], (a, "alice", 999)).rowcount == 0) and bal(c, a) == 150)
check("debit more than balance is rejected (never negative)", move(c, a, -151) is False and bal(c, a) == 150)
check("debit exactly the balance works", move(c, a, -150) is True and bal(c, a) == 0)
check("credit works", move(c, a, 40) is True and bal(c, a) == 40)
try: c.execute("UPDATE accounts SET dollars=-5 WHERE uuid=?", (a,)); neg = True
except sqlite3.IntegrityError: neg = False
check("CHECK constraint blocks a negative balance even for a buggy direct write", neg is False and bal(c, a) == 40)
check("each COMMITTED move left one history row; the rejected debit left none", c.execute("SELECT COUNT(*) FROM tx WHERE uuid=?", (a,)).fetchone()[0] == 2)

print("== SELL (the reported bug): payment, stock and rollback")
c, path = new_db(); s = add(c, "seller", 0)
c.execute(SQL["MARKET_STOCK_RETURN"].replace("stock=stock+?", "stock=stock+?"), (0, "CARROT"))  # no row yet: no-op
c.execute("INSERT INTO market_state(material,up,multiplier,price,stock) VALUES('CARROT',1,1.0,3,100)")
bundles, price = 48, 3           # 12 stacks of 64 carrots = 768 = 48 bundles of 16
ok = move(c, s, bundles*price, "SELL", lambda cc: cc.execute(SQL["MARKET_STOCK_TAKE"], (bundles, "CARROT", bundles)).rowcount == 1)
check("12 stacks of carrots (48 bundles) pays $144", ok and bal(c, s) == 144)
check("market stock reduced by exactly 48", c.execute("SELECT stock FROM market_state WHERE material='CARROT'").fetchone()[0] == 52)
ok = move(c, s, 60*price, "SELL", lambda cc: cc.execute(SQL["MARKET_STOCK_TAKE"], (60, "CARROT", 60)).rowcount == 1)
check("selling more than the remaining stock fails ENTIRELY (no payment)", ok is False and bal(c, s) == 144)
check("...and the stock is unchanged after that failed sale", c.execute("SELECT stock FROM market_state WHERE material='CARROT'").fetchone()[0] == 52)
ok = move(c, s, -144, "SELL_REVERSE", lambda cc: cc.execute(SQL["MARKET_STOCK_RETURN"], (48, "CARROT")).rowcount == 1)
check("sale reversal returns the money AND the stock", ok and bal(c, s) == 0 and c.execute("SELECT stock FROM market_state WHERE material='CARROT'").fetchone()[0] == 100)

print("== SHOP / KIT purchases")
c, path = new_db(); b = add(c, "buyer", 500)
check("purchase deducts exactly the price", move(c, b, -173, "SHOP") and bal(c, b) == 327)
check("cannot buy with insufficient funds, balance untouched", move(c, b, -328, "SHOP") is False and bal(c, b) == 327)
kit_ok = move(c, b, -102, "KIT", lambda cc: cc.execute(SQL["KIT_STAMP"], (b, "beginner", 1)).rowcount == 1)
check("kit charge + cooldown stamp commit together", kit_ok and c.execute("SELECT COUNT(*) FROM kit_cooldowns").fetchone()[0] == 1)
move(c, b, 102, "KIT_REFUND", lambda cc: cc.execute(SQL["KIT_UNSTAMP"], (b, "beginner")).rowcount == 1)
check("kit refund returns money and removes the stamp", bal(c, b) == 327 and c.execute("SELECT COUNT(*) FROM kit_cooldowns").fetchone()[0] == 0)
fail = move(c, b, -50, "KIT", lambda cc: False)
check("a failing extra step rolls the charge back", fail is False and bal(c, b) == 327)

print("== /pay atomicity")
c, path = new_db(); x = add(c, "x", 100); y = add(c, "y", 0)
def pay(c, f, t, n):
    c.execute("BEGIN")
    if c.execute(SQL["DEBIT"], (n, f, n)).rowcount != 1: c.execute("ROLLBACK"); return False
    if c.execute(SQL["CREDIT"], (n, t)).rowcount != 1: c.execute("ROLLBACK"); return False
    c.execute("COMMIT"); return True
check("pay moves exactly the amount, total money conserved", pay(c, x, y, 60) and bal(c, x) == 40 and bal(c, y) == 60)
check("overdraft pay rejected, nothing moves", pay(c, x, y, 41) is False and bal(c, x) == 40 and bal(c, y) == 60)
ghost = str(uuid.uuid4())
check("pay to a non-existent account rolls the debit back", pay(c, x, ghost, 10) is False and bal(c, x) == 40)

print("== bounty claim runs exactly once")
c, path = new_db(); k = add(c, "killer", 0); v = add(c, "victim", 0, bounty=300)
def claim(vb):
    return move(c, k, vb, "BOUNTY", lambda cc: cc.execute(SQL["BOUNTY_CLAIM"], (v, vb)).rowcount == 1 and cc.execute(SQL["BOUNTY_ADD"], (1000000, 50, k)).rowcount == 1)
check("first claim pays the bounty, resets victim, raises killer bounty", claim(300) and bal(c, k) == 300 and bnty(c, v) == 0 and bnty(c, k) == 50)
check("SECOND claim of the same bounty pays nothing (duplicate event / race)", claim(300) is False and bal(c, k) == 300)
check("BOUNTY_ADD respects the max-bounty cap", c.execute(SQL["BOUNTY_ADD"], (60, 50, k)).rowcount == 1 and bnty(c, k) == 60)

print("== concurrency: two simultaneous spends of the same money")
c, path = new_db(); u = add(c, "racer", 100); c.close()
results = []
def spend():
    cn = sqlite3.connect(path, isolation_level=None, timeout=10)   # each worker has its own connection
    results.append(move(cn, u, -80)); cn.close()
ts = [threading.Thread(target=spend) for _ in range(2)]
[t.start() for t in ts]; [t.join() for t in ts]
chk = sqlite3.connect(path, isolation_level=None)
check("only ONE of two simultaneous $80 purchases succeeds with $100", results.count(True) == 1 and results.count(False) == 1 and bal(chk, u) == 20, str(results))

print("== persistence across restart")
c, path = new_db(); p = add(c, "persist", 150); move(c, p, 77); c.close()
c2 = sqlite3.connect(path, isolation_level=None)
check("balance survives close/reopen", bal(c2, p) == 227)

print("== migration of an OLD database (Iron/Diamond schema)")
old = tempfile.mktemp(suffix=".db"); oc = sqlite3.connect(old, isolation_level=None)
oc.execute("CREATE TABLE accounts (uuid TEXT PRIMARY KEY, name TEXT NOT NULL, iron INTEGER NOT NULL DEFAULT 0 CHECK(iron>=0), diamonds INTEGER NOT NULL DEFAULT 0 CHECK(diamonds>=0), bounty INTEGER NOT NULL DEFAULT 0 CHECK(bounty>=0))")
o1, o2, o3 = str(uuid.uuid4()), str(uuid.uuid4()), str(uuid.uuid4())
oc.execute("INSERT INTO accounts VALUES(?,?,?,?,?)", (o1, "rich", 100, 5, 40)); oc.execute("INSERT INTO accounts VALUES(?,?,?,?,?)", (o2, "iron-only", 30, 0, 0)); oc.execute("INSERT INTO accounts VALUES(?,?,?,?,?)", (o3, "empty", 0, 0, 7))
def cols(cn): return {r[1] for r in cn.execute("PRAGMA table_info(accounts)")}
def upgrade(cn):
    if "dollars" not in cols(cn): cn.execute(SQL["ADD_DOLLARS"])
    if "migrated" not in cols(cn): cn.execute(SQL["ADD_MIGRATED"])
upgrade(oc); upgrade(oc)
check("upgrade adds the new columns and is safe to run twice", {"dollars", "migrated"} <= cols(oc))
check("upgrade keeps every old row, balance and bounty", oc.execute("SELECT iron,diamonds,bounty FROM accounts WHERE uuid=?", (o1,)).fetchone() == (100, 5, 40) and oc.execute("SELECT COUNT(*) FROM accounts").fetchone()[0] == 3)
check("new accounts on an upgraded DB work (CHECK on added column)", oc.execute(SQL["INSERT_ACCOUNT"], (str(uuid.uuid4()), "new", 150)).rowcount == 1)
n, ti, td = oc.execute(SQL["MIG_PREVIEW"]).fetchone()
check("preview counts only accounts that still hold Iron/Diamonds", (n, ti, td) == (2, 130, 5))
IRON, DIA = 8, 60
def migrate(cn):
    cn.execute("BEGIN"); done = 0
    for u, i, d in cn.execute(SQL["MIG_SELECT"]).fetchall():
        if cn.execute(SQL["MIG_APPLY"], (i*IRON + d*DIA, u)).rowcount == 1: done += 1
    cn.execute("COMMIT"); return done
check("migration converts both accounts with the configured rates", migrate(oc) == 2 and bal(oc, o1) == 100*8+5*60 and bal(oc, o2) == 240)
check("running the migration AGAIN changes nothing (no double credit)", migrate(oc) == 0 and bal(oc, o1) == 1100)
check("old Iron/Diamond columns and bounty are preserved after migration", oc.execute("SELECT iron,diamonds,bounty FROM accounts WHERE uuid=?", (o1,)).fetchone() == (100, 5, 40))

print("== leaderboard / baltop ordering")
c, path = new_db()
for nme, bo, do in (("a", 10, 5), ("b", 500, 1), ("c", 50, 900)): add(c, nme, do, bo)
check("LEADERBOARD orders by bounty desc", [r[1] for r in c.execute(SQL["LEADERBOARD"], (0, 10))] == ["b", "c", "a"])
check("BALTOP orders by dollars desc", [r[1] for r in c.execute(SQL["BALTOP"], (10,))] == ["c", "a", "b"])

print(f"\n{passed} passed, {failed} failed")
sys.exit(1 if failed else 0)
