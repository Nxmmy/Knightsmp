# Mods For KnightSMP

Anarchy-style Paper plugin: **Dollar ($) economy**, /shop, /shopkits, /sell with a 24-hour dynamic market, bounties with a WANTED #1 role, and combat logging.
Server-side only; Java and Bedrock (Geyser/Floodgate) players use the same plain chest menus. There are **no teleport commands** (vanilla `/tp` is untouched).

Requirements: Paper 26.3, Java 25. Optional: ViaVersion, ViaBackwards, Geyser-Spigot, Floodgate.

## Commands
| Command | What it does |
|---|---|
| `/money` | Balance + wallet menu (recent transactions, transfer) |
| `/money <player>` | Another player's balance |
| `/pay <player> <amount>` | Send whole Dollars |
| `/baltop` | Richest players |
| `/bounty` | Bounty leaderboard menu |
| `/shop` `/shopkits` `/sell` | Shop, kit shop, market |
| `/moneyadmin give/take/set <player> <amount>` | Admin balance control (`knightsmp.admin.money`) |
| `/moneyadmin migrate [confirm]` | Convert old Iron/Diamond balances (see below) |
| `/knight reload`, `setbounty`, `resetbounty`, `market reload/refresh` | Admin |

## How money stays safe
* Balances are whole-dollar `long`s in SQLite. The database is the source of truth; memory is updated only after a commit.
* Every money movement is **one SQL transaction**: conditional debit (`... AND dollars >= ?`), history row, and any extra step (market stock, kit cooldown, bounty claim) commit together or not at all. A `CHECK(dollars>=0)` backs it up.
* **/sell**: the sale is committed first (payment + stock, conditional on stock still being there), *then* the items are removed. If the items can't be removed (dropped/moved/player left) the payment and stock are reversed. "Sold" is only shown after both succeeded. Items are never taken without payment.
* **/shop and /shopkits**: charge first (conditional on funds), then deliver; if delivery turns out to be impossible the charge is refunded.
* One transaction per player at a time (rapid clicks get "please wait"). On shutdown, in-flight transactions are finished before the database closes.
* Bounty claims use compare-and-set (`UPDATE ... WHERE bounty = <value read>`), so a bounty can pay only once. A kill blocked by anti-abuse rules changes nothing (no reward, no reset), so an alt can't wash a bounty away.
* Database failures are logged (`SEVERE`) with the transaction type and the player is told nothing was taken/paid.

## Pricing model (all prices in config files)
Every item has a value V. Crafted items: V = sum of ingredient values. Shop price = V x1.15 (crafted) or x1.25 (raw), rounded up. Non-craftable rarities (elytra, totem, enchanted golden apple, beacon...) use explicit rarity values. Market sell price = V x0.40 per bundle (min $1), then the daily UP/DOWN multiplier (x0.4 - x2.0) applies, so buying and re-selling is never profitable. Kits = (sum of item values + enchantment premiums) x0.85.
Examples: diamond pickaxe $173 (crafting ~ $151), iron pickaxe $21, Beginner kit $102, Endgame kit $18,728. New accounts start with $150 (`economy.starting-balance`).

## Upgrading an old database (Iron/Diamond)
* On first start the plugin adds `dollars`/`migrated` columns to the existing `accounts` table after writing `knightsmp.db.pre-dollars-<time>.bak`. Nothing is deleted; old `iron`/`diamonds`/`bounty` values and UUIDs stay as they are. Safe to run repeatedly.
* **No conversion happens automatically.** Set `migration.iron-rate` and `migration.diamond-rate` in `config.yml` (`-1` = undecided), `/knight reload`, run `/moneyadmin migrate` for a preview, then `/moneyadmin migrate confirm`. A second backup is written, every account converts exactly once, and the old columns are kept. Old bounty values carry over unchanged (they are now dollars).
* Old transaction history rows are kept and shown as "old currency".
* The old `homes` table is left in place, unused.

## Build
`gradle build` (JDK 25). The flat repository layout builds with the included `build.gradle.kts`; GitHub Actions uploads `ModsForKnightSMP-1.0.0.jar`.

## Tests
* `python3 sql_tests.py Sql.java` - runs the plugin's real SQL statements on SQLite: sell/purchase/refund/pay atomicity, no negative balances, bounty single-claim, simultaneous spends, persistence, old-schema upgrade + migration idempotency.
* `python3 static_checks.py .` - teleport/currency removal, command/permission/message consistency, price sanity.
These do **not** replace testing on a real server (see the final report for what was and wasn't tested).
