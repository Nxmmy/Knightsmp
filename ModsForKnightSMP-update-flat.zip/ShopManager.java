package dev.knightsmp.mods.shop;

import dev.knightsmp.mods.KnightPlugin;
import dev.knightsmp.mods.economy.Account;
import dev.knightsmp.mods.economy.EconomyManager.Change;
import dev.knightsmp.mods.util.Items;
import dev.knightsmp.mods.util.Money;
import dev.knightsmp.mods.util.Text;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class ShopManager {
    public record ShopItem(Material material, int amount, long price, String desc) {}
    public record Category(String id, String name, Material icon, List<String> desc, List<ShopItem> items) {}

    private final KnightPlugin plugin;
    private final Map<String, Category> categories = new LinkedHashMap<>();

    public ShopManager(KnightPlugin plugin) { this.plugin = plugin; }
    public Map<String, Category> categories() { return categories; }

    public void load() {
        categories.clear();
        YamlConfiguration y = plugin.yaml("shop.yml");
        ConfigurationSection root = y.getConfigurationSection("categories");
        if (root == null) { plugin.getLogger().warning("shop.yml has no 'categories' section."); return; }
        for (String id : root.getKeys(false)) {
            ConfigurationSection s = root.getConfigurationSection(id);
            if (s == null) continue;
            Material icon = Material.matchMaterial(s.getString("icon", "CHEST"));
            List<ShopItem> items = new ArrayList<>();
            for (Map<?, ?> m : s.getMapList("items")) {
                Material mat = Material.matchMaterial(String.valueOf(m.get("material")));
                if (mat == null || !mat.isItem()) { plugin.getLogger().warning("shop.yml: skipping invalid item " + m + " in category " + id); continue; }
                int amount = m.get("amount") instanceof Number n ? Math.max(1, n.intValue()) : 1;
                long price = m.get("price") instanceof Number n ? n.longValue() : -1;
                if (price < 1) { plugin.getLogger().warning("shop.yml: item " + mat + " has no valid price - skipped."); continue; }
                items.add(new ShopItem(mat, amount, price, m.get("desc") == null ? null : String.valueOf(m.get("desc"))));
            }
            categories.put(id, new Category(id, s.getString("name", id), icon == null ? Material.CHEST : icon, s.getStringList("description"), items));
        }
    }

    public int maxQuantity() { return plugin.getConfig().getInt("shop.max-quantity", 64); }

    /**
     * Charge first (atomic, conditional on funds), then deliver; if delivery turns out to be impossible
     * (inventory filled meanwhile, player left) the charge is refunded. A player is never charged without getting the item.
     */
    public void purchase(Player p, ShopItem it, int qty, Runnable after) {
        Account a = plugin.economy.get(p);
        if (a == null) { after.run(); return; }
        if (qty < 1 || qty > maxQuantity()) { plugin.send(p, "invalid-amount"); after.run(); return; }
        final long total;
        try { total = Math.multiplyExact(it.price(), (long) qty); }
        catch (ArithmeticException e) { plugin.send(p, "invalid-amount"); after.run(); return; }
        final List<ItemStack> stacks = Items.stacks(it.material(), (long) it.amount() * qty);
        if (!Items.canFit(p, stacks)) { plugin.send(p, "shop-no-space"); after.run(); return; }
        if (a.dollars < total) { plugin.send(p, "shop-no-funds", "%price%", Money.fmt(total), "%balance%", Money.fmt(a.dollars)); after.run(); return; }
        if (!plugin.economy.tryLock(a.id)) { plugin.send(p, "tx-busy"); after.run(); return; }

        final String what = (long) it.amount() * qty + "x " + Text.pretty(it.material());
        plugin.economy.commit("SHOP", List.of(new Change(a.id, -total, null, "SHOP")), null, null, ok -> {
            if (!ok) { plugin.economy.unlock(a.id); plugin.send(p, "shop-no-funds", "%price%", Money.fmt(total), "%balance%", Money.fmt(a.dollars)); after.run(); return; }
            if (p.isOnline() && Items.canFit(p, stacks)) {
                Items.give(p, stacks);
                plugin.economy.unlock(a.id);
                plugin.send(p, "shop-bought", "%item%", what, "%price%", Money.fmt(total));
                after.run();
            } else {
                plugin.getLogger().warning("Shop delivery failed for " + p.getName() + " (" + what + "); refunding " + total);
                plugin.economy.commit("SHOP_REFUND", List.of(new Change(a.id, total, null, "SHOP_REFUND")), null, null, ok2 -> {
                    if (!ok2) plugin.getLogger().severe("REFUND FAILED for " + p.getName() + ": owed $" + total + " - fix manually with /moneyadmin give.");
                    plugin.economy.unlock(a.id);
                    plugin.send(p, "shop-refunded");
                    after.run();
                });
            }
        });
    }
}
