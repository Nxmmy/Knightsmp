"""Repository consistency checks (no server needed). Usage: python3 static_checks.py <repo-root>   (works for nested or flat layout)"""
import os, re, sys, yaml
root = sys.argv[1] if len(sys.argv) > 1 else "."
java = {}
res = {}
for d, _, fs in os.walk(root):
    if ".git" in d: continue
    for f in fs:
        p = os.path.join(d, f)
        if f.endswith(".java"): java[f] = open(p).read()
        if f in ("plugin.yml", "config.yml", "shop.yml", "kits.yml", "market.yml"): res[f] = open(p).read()
allj = "\n".join(java.values())
y = {k: yaml.safe_load(v) for k, v in res.items()}
passed = failed = 0
def check(n, c, d=""):
    global passed, failed
    if c: passed += 1; print("  PASS ", n)
    else: failed += 1; print("  FAIL ", n, d)

print("== teleport system removed")
tp_cmds = {"tpa", "tpaccept", "tpdeny", "home", "sethome", "delhome", "back", "spawn", "setspawn", "rtp"}
cmds = set(y["plugin.yml"]["commands"])
check("none of the 10 teleport commands are registered in plugin.yml", not (cmds & tp_cmds), str(cmds & tp_cmds))
check("no TeleportManager / teleport references remain in Java", not re.search(r"TeleportManager|plugin\.teleport|teleportAsync|PlayerTeleportEvent", allj))
check("no teleport permissions remain", not [p for p in y["plugin.yml"]["permissions"] if re.search(r"\.(tp|home|back|spawn|rtp)$", p)])
check("no 'teleport:' section left in config.yml", "teleport" not in y["config.yml"])
check("TeleportManager.java is gone", "TeleportManager.java" not in java)

print("== Iron/Diamond currency removed")
check("Currency.java is gone and nothing references it", "Currency.java" not in java and "Currency" not in allj)
check("no iron/diamond payment code in Java except the legacy migration columns", not re.search(r"IRON_INGOT|Material\.DIAMOND\b|payout-mode|spend-from-inventory|deposit|withdraw", allj))
check("shop/kits/market yml contain no currency fields", not re.search(r"currency\s*:", res["shop.yml"] + res["kits.yml"] + res["market.yml"]))

print("== commands / permissions")
cmd_src = java["Commands.java"]
for c in cmds:
    check(f"/{c} has a handler in Commands.java", f'"{c}"' in cmd_src)
perms = set(y["plugin.yml"]["permissions"])
for c, v in y["plugin.yml"]["commands"].items():
    check(f"/{c} permission '{v['permission']}' is declared", v["permission"] in perms or v["permission"] in {k for p in y["plugin.yml"]["permissions"].values() if isinstance(p, dict) for k in (p.get("children") or {})})
used = set(re.findall(r'perm\(s, "([\w.]+)"\)|hasPermission\("([\w.]+)"\)', allj))
used = {a or b for a, b in used}
declared = perms | {k for p in y["plugin.yml"]["permissions"].values() if isinstance(p, dict) for k in (p.get("children") or {})}
check("every permission checked in code is declared in plugin.yml", used <= declared, str(used - declared))
check("main class path in plugin.yml exists", "KnightPlugin.java" in java and y["plugin.yml"]["main"].endswith("KnightPlugin"))

print("== messages")
keys = set(y["config.yml"]["messages"])
code_keys = set(re.findall(r'(?:send|broadcast|msg|raw)\((?:[\w.()]+, )?"([a-z0-9-]+)"', allj))
code_keys |= set(re.findall(r'"((?:sell|shop|kit|pay|tx|bounty|combat|balance|baltop|admin|migrate|market|player|invalid|usage|reloaded|db|no|wanted)-[a-z0-9-]+|reloaded|usage)"', allj))
missing = {k for k in code_keys if k not in keys and k not in ("admin-",)}
check("every message key used in code exists in config.yml", not missing, str(sorted(missing)))
check("admin-give/take/set exist (built dynamically)", {"admin-give", "admin-take", "admin-set"} <= keys)

print("== prices")
shop = y["shop.yml"]["categories"]
check("shop has the 8 required categories", set(shop) == {"building", "nature", "ores", "redstone", "food", "combat", "tools", "misc"}, str(set(shop)))
bad = [(c, i["material"]) for c, v in shop.items() for i in v["items"] if not isinstance(i.get("price"), int) or i["price"] < 1]
check("every shop item has a whole-dollar price >= 1", not bad, str(bad))
price = {i["material"]: i["price"] for v in shop.values() for i in v["items"]}
check("diamond pickaxe is priced near its crafting cost (3 diamonds + 2 sticks ~ $151)", 150 <= price["DIAMOND_PICKAXE"] <= 200, str(price["DIAMOND_PICKAXE"]))
check("iron pickaxe is cheaper than diamond pickaxe and affordable", price["IRON_PICKAXE"] < 40 < price["DIAMOND_PICKAXE"])
check("armor/tool price order is sensible (iron < diamond)", price["IRON_CHESTPLATE"] < price["DIAMOND_CHESTPLATE"])
kits = y["kits.yml"]["kits"]
kp = {k: v["price"] for k, v in kits.items()}
check("kit price progression beginner < intermediate < advanced < endgame", kp["beginner"] < kp["intermediate"] < kp["advanced"] < kp["endgame"], str(kp))
check("starter kit is free and Beginner is within reach of the starting balance x1", kp["starter"] == 0 and kp["beginner"] <= y["config.yml"]["economy"]["starting-balance"] * 1.0 + 5, str(kp["beginner"]))
check("endgame kit includes netherite armor, elytra, spear entry", all(any(i["material"] == m for i in kits["endgame"]["items"]) for m in ("NETHERITE_HELMET", "NETHERITE_CHESTPLATE", "NETHERITE_LEGGINGS", "NETHERITE_BOOTS", "ELYTRA", "NETHERITE_SPEAR")))
market = y["market.yml"]
mats = {i["material"]: i for c in market["categories"].values() for i in c["items"]}
check("market kept: 24h refresh, up/down multipliers, stock, categories", market["refresh-hours"] == 24 and "up-multiplier" in market and "stock" in market and len(market["categories"]) >= 5)
check("market has no sell price below $1 and none above its shop price", all(i["price"] >= 1 for i in mats.values()) and mats["DIAMOND"]["price"] < price["DIAMOND"])
check("no buy-and-resell profit even at the maximum x2.0 market multiplier (sell value per unit < shop price per unit)", all((mats[m]["price"] / mats[m]["bundle"]) * market["up-multiplier"]["max"] < price.get(m, 10**9) / next((i["amount"] for v in shop.values() for i in v["items"] if i["material"] == m), 1) for m in mats if m in price))
check("carrots sell (the reported item) and 12 stacks pay > $0", "CARROT" in mats and (12 * 64 // mats["CARROT"]["bundle"]) * mats["CARROT"]["price"] > 0, str(mats.get("CARROT")))

print("== migration policy")
mg = y["config.yml"]["migration"]
check("migration never runs silently: rates default to 'unset' (-1)", mg["iron-rate"] == -1 and mg["diamond-rate"] == -1)
check("Database makes a backup before upgrading", "backup(conn, \"pre-dollars\")" in java["Database.java"] and "pre-migration" in java["EconomyManager.java"])

print("== combat log kept")
check("CombatManager + quit punishment + shutdown guard present", "CombatManager.java" in java and "isStopping()" in java["Listeners.java"] and "setHealth(0.0)" in java["Listeners.java"])
check("combat has no teleport restrictions left", "teleport" not in java["CombatManager.java"].lower())
print(f"\n{passed} passed, {failed} failed"); sys.exit(1 if failed else 0)
