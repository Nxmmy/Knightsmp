package dev.knightsmp.mods.util;

/** Dollar formatting. All balances are whole dollars stored as long (no floating point). */
public final class Money {
    private Money() {}
    public static String fmt(long n) { return "&a$" + Text.num(n); }
}
